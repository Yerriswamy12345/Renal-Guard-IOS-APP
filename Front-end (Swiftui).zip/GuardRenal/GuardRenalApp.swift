//
//  GuardRenalApp.swift
//  GuardRenal
//
//  Created by SAIL L1 on 06/01/26.
//

import SwiftUI

@main
struct GuardRenalApp: App {
    var body: some Scene {
        WindowGroup {
            Mainpage()
        }
    }
}
