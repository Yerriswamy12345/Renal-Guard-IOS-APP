//
//  ContentView.swift
//  Renal Guard
//
//  Created by Sail L1 on 30/08/25.
//

import SwiftUI

// This file keeps the original HomeView for backwards compatibility
// The actual app now uses Mainpage.swift from Preview Content folder

struct HomeView: View {
    @State private var navigateToLogin = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color.white
                    .ignoresSafeArea()
                
                VStack {
                    Spacer()
                    
                    Image("Image 1")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: min(300, UIScreen.main.bounds.width * 0.7))
                        .aspectRatio(contentMode: .fit)
                    
                    Spacer()
                    
                    Button(action: {
                        navigateToLogin = true
                    }) {
                        Text("Get Started")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.white)
                            .padding(.vertical, 14)
                            .padding(.horizontal, 50)
                            .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                            .cornerRadius(40)
                    }
                    .padding(.bottom, 60)
                }
            }
            .navigationDestination(isPresented: $navigateToLogin) {
                LoginView()
                    .navigationBarBackButtonHidden(true)
            }
        }
    }
}

#Preview {
    HomeView()
}

