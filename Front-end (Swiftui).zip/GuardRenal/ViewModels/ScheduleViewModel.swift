import Foundation
import SwiftUI

@MainActor
class ScheduleViewModel: ObservableObject {
    @Published var doctorSchedules: [APISchedule] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showSuccess = false
    @Published var successMessage: String?
    

    
    // MARK: - Create Schedule
    func createSchedule(doctorEmail: String, date: String, startTime: String, endTime: String) async {
        await MainActor.run {
            self.isLoading = true
            self.errorMessage = nil
            self.showSuccess = false
        }
        
        let parameters: [String: Any] = [
            "doctor_email": doctorEmail,
            "available_date": date,
            "start_time": startTime,
            "end_time": endTime
        ]
        
        NetworkManager.shared.postRequest(endpoint: "addSchedule.php", parameters: parameters, responseType: SchedulePHPResponse.self) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    if response.success {
                        self.showSuccess = true
                        self.successMessage = response.message
                    } else {
                        self.errorMessage = response.message
                    }
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    // MARK: - Fetch Doctor Schedules
    func fetchDoctorSchedules(doctorEmail: String) async {
        await MainActor.run {
            self.isLoading = true
            self.errorMessage = nil
        }
        
        let parameters: [String: Any] = [
            "doctor_email": doctorEmail
        ]
        
        NetworkManager.shared.postRequest(endpoint: "get_all_doctor_schedules.php", parameters: parameters, responseType: DoctorSchedulesResponse.self) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    if response.success {
                        // Map APISchedule to DoctorSchedule if needed, but for now we'll use a new published property or update the existing one
                        // Let's create a more specific property for these detailed schedules
                        self.doctorSchedules = response.schedules ?? []
                    } else {
                        self.errorMessage = response.message
                    }
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    // MARK: - Reset States
    func resetSuccess() {
        showSuccess = false
        successMessage = nil
    }
    
    func resetError() {
        errorMessage = nil
    }
}

struct SchedulePHPResponse: Codable {
    let success: Bool
    let message: String
}

struct DoctorSchedulesResponse: Codable {
    let success: Bool
    let message: String?
    let doctor_email: String?
    let schedules: [APISchedule]?
}

struct APISchedule: Identifiable, Codable {
    let schedule_id: String
    let available_date: String
    let start_time: String
    let end_time: String
    let slot_duration: String
    let max_patients: String
    let booked_count: String
    let remaining: Int
    let status: String
    let patients: [APIPatient]
    
    var id: String { schedule_id }
}

struct APIPatient: Identifiable, Codable {
    let appointment_id: String
    let slot_time: String
    let status: String
    let patient_name: String
    let patient_email: String
    let patient_phone: String
    
    var id: String { appointment_id }
}
