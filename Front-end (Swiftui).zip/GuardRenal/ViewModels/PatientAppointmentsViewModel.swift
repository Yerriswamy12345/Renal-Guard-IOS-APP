import Foundation
import SwiftUI

// Response model
struct PatientAppointmentsResponse: Codable {
    let success: Bool
    let message: String?
    let appointments: [Appointment]?
}

// Ensure Appointment is Codable and matches PHP response
struct Appointment: Identifiable, Codable {
    var id: String { appointment_id } // Use appointment_id as unique ID
    
    let appointment_id: String
    let slot: String      // "10:00:00 - 13:00:00"
    let date: String      // "2025-10-14"
    let slotTime: String  // "10:15:00"
    let status: String    // "missed", "attended", "booked"
}

@MainActor
class PatientAppointmentsViewModel: ObservableObject {
    @Published var appointments: [Appointment] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func fetchAppointments(patientEmail: String) {
        guard !patientEmail.isEmpty else {
            self.errorMessage = "Patient email not found"
            return
        }
        
        self.isLoading = true
        self.errorMessage = nil
        
        let parameters = ["patient_email": patientEmail]
        
        NetworkManager.shared.postRequest(
            endpoint: "get_patient_appointments.php",
            parameters: parameters,
            responseType: PatientAppointmentsResponse.self
        ) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let response):
                    if response.success {
                        self?.appointments = response.appointments ?? []
                    } else {
                        self?.errorMessage = response.message ?? "Failed to load appointments"
                    }
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    // Placeholder for cancel action - to be implemented fully if API exists
    // ✅ Update Appointment Status API
    func updateAppointmentStatus(appointmentId: String, status: String, patientEmail: String) {
        guard let id = Int(appointmentId) else { return }
        
        let parameters: [String: Any] = [
            "appointment_id": id,
            "patient_email": patientEmail,
            "status": status
        ]
        
        NetworkManager.shared.postRequest(
            endpoint: "updateAppointment.php",
            parameters: parameters,
            responseType: UpdateResponse.self
        ) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.success {
                        print("Status updated to \(status)")
                        // Refresh list
                        self?.fetchAppointments(patientEmail: patientEmail)
                    } else {
                        self?.errorMessage = response.message
                    }
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
}

// Helper Response Struct
struct UpdateResponse: Codable {
    let success: Bool
    let message: String
}

