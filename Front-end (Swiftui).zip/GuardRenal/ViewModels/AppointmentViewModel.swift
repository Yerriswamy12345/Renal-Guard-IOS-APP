import Foundation
import SwiftUI

@MainActor
class AppointmentViewModel: ObservableObject {
    @Published var vardoctorsWithSchedules: [DoctorWithSchedule] = []
    @Published var availableSlots: [ScheduleWithSlots] = []
    @Published var daySchedules: [DaySchedule] = []
    @Published var selectedDoctor: DoctorWithSchedule?
    @Published var selectedSlot: TimeSlot?
    @Published var selectedSchedule: ScheduleWithSlots?
    @Published var bookedAppointment: BookingData?
    @Published var patientAppointments: [BookedAppointment] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showSuccess = false
    
    // MARK: - Fetch Doctors with Schedules
    func fetchDoctorsWithSchedules() async {
        // Not used in this specific flow
    }
    
    // MARK: - Fetch Day Schedules
    func fetchDaySchedules(doctorId: String, date: String) async {
        self.isLoading = true
        self.errorMessage = nil
        
        let parameters: [String: Any] = [
            "doctor_id": doctorId,
            "date": date
        ]
        
        // Use GET request since PHP looks for $_GET['doctor_id'] and $_GET['date'] primarily
        // but NetworkManager.shared.postRequest is what we have been using.
        // The PHP script has: $doctor_id = $_GET['doctor_id'] ?? ($_POST['doctor_id'] ?? '');
        // So POST will work.
        
        NetworkManager.shared.postRequest(endpoint: "get_doctor_schedules.php", parameters: parameters, responseType: DaySchedulesResponse.self) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    if response.success {
                        self.daySchedules = response.schedules
                    } else {
                        self.errorMessage = "No schedules found"
                    }
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    // MARK: - Fetch Available Slots
    func fetchAvailableSlots(doctorId: String, scheduleId: Int? = nil, date: String) async {
        guard let scheduleId = scheduleId else { return }
        self.isLoading = true
        self.errorMessage = nil
        
        // Match getAvailableSlots.php expectation: schedule_id
        let parameters: [String: Any] = ["schedule_id": scheduleId]
        
        NetworkManager.shared.postRequest(endpoint: "getAvailableSlots.php", parameters: parameters, responseType: AvailableSlotsResponse.self) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    if response.success {
                        let slots = response.slots.enumerated().map { index, timeStr in
                            // Initialize TimeSlot correctly according to global definition
                            TimeSlot(
                                id: index + 1, 
                                slotStartTime: timeStr,
                                slotEndTime: "", // Not returned by API
                                slotStatus: "available"
                            )
                        }
                        
                        self.availableSlots = [
                            ScheduleWithSlots(
                                scheduleId: scheduleId,
                                scheduleDate: response.date ?? date,
                                startTime: "", 
                                endTime: "", 
                                totalSlots: slots.count,
                                remainingSlots: slots.count,
                                status: "active",
                                availableSlots: slots
                            )
                        ]
                    } else {
                        self.errorMessage = "Failed to load slots"
                    }
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    // MARK: - Book Appointment
    func bookAppointment(patientId: Int, slotId: Int, scheduleId: Int, patientEmail: String, slotTime: String, doctorId: String, appointmentDate: String) async {
        self.isLoading = true
        self.errorMessage = nil
        self.showSuccess = false
        
        // Match bookAppointment.php expectation: schedule_id, patient_email, slot_time
        let parameters: [String: Any] = [
            "schedule_id": scheduleId,
            "patient_email": patientEmail, 
            "slot_time": slotTime
        ]
        
        return await withCheckedContinuation { continuation in
            NetworkManager.shared.postRequest(endpoint: "bookAppointment.php", parameters: parameters, responseType: BookingResponse.self) { result in
                DispatchQueue.main.async {
                    self.isLoading = false
                    switch result {
                    case .success(let response):
                        if response.success {
                            self.showSuccess = true
                            self.bookedAppointment = BookingData(
                                appointmentId: 0,
                                patientId: patientId,
                                doctorId: doctorId,
                                doctorName: "",
                                scheduleDate: appointmentDate,
                                slotTime: slotTime,
                                bookingTime: ""
                            )
                        } else {
                            self.errorMessage = response.message
                        }
                    case .failure(let error):
                        self.errorMessage = error.localizedDescription
                    }
                    continuation.resume()
                }
            }
        }
    }
    
}
