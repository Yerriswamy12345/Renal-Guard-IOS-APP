import Foundation

// MARK: - Score Response Model
struct ScoreListResponse: Codable {
    let success: Bool
    let count: Int?
    let scores: [ScoreModel]?
}

// MARK: - Individual Score Model
struct ScoreModel: Codable, Identifiable {
    let score_id: Int
    let score: Int
    let created_at: String
    
    var id: Int { score_id }
    
    // Formatted date for display
    var formattedDate: String {
        // Convert "2025-10-28 10:30:45" to "2025-10-28"
        let components = created_at.components(separatedBy: " ")
        return components.first ?? created_at
    }
}

// MARK: - Doctor Dashboard Patient Model (with latest score)
struct DoctorPatientResponse: Codable {
    let success: Bool
    let count: Int? // Optional because get_patients.php might not return it
    let patients: [DoctorPatientModel]
}

struct DoctorPatientModel: Codable, Identifiable {
    let patient_id: String // Changed to String
    let user_id: Int
    let name: String?
    let email: String?
    let phone: String?
    let age: Int?
    let gender: String?
    // patientNo removed from JSON. We can use patient_id as patientNo.
    // If backend doesn't send "patientNo", we can't let it be stored property if it's not in JSON.
    // get_patients.php sends: user_id, name, age, gender, patient_id, email, phone, latest_score, latest_date.
    // It DOES NOT send "patientNo".
    // So "patientNo" in struct must be computed or mapped from patient_id.
    // I will remove stored property patientNo and use computed property.
    let latest_score: Int?
    let latest_date: String?
    
    // Custom coding keys if needed, but names match.
    // user_id maps to user_id (aliased in SQL).
    
    var id: Int { user_id }
    
    // Computed property for display
    var displayName: String {
        return name ?? "Unknown Name"
    }
    
    var patientNo: String {
        return patient_id
    }
    
    var displayPatientNo: String {
        return "ID: \(patient_id)"
    }
    
    var displayAge: String {
        if let age = age {
            return "\(age)"
        }
        return "N/A"
    }
    
    var displayGender: String {
        return gender ?? "N/A"
    }
    
    var displayEmail: String {
        return email ?? "No Email"
    }
    
    var scoreDisplay: String {
        if let score = latest_score {
            return "\(score)"
        }
        return "No assessment"
    }
    
    var dateDisplay: String {
        if let date = latest_date {
            let components = date.components(separatedBy: " ")
            return components.first ?? "N/A"
        }
        return "N/A"
    }
}

// MARK: - Save Score Response
struct SaveScoreResponse: Codable {
    let success: Bool
    let message: String
    let patient_id: Int?
    let doctor_user_id: Int?
    let score: Int?
}

// MARK: - Risk Recommendation Helper
func getRiskRecommendation(score: Int) -> String {
    switch score {
    case 0...5:
        return "Low risk: Minimal infection risk. Standard hygiene protocols recommended."
    case 6...12:
        return "Moderate risk: Doctor's discretion based on symptoms."
    case 13...25:
        return "High risk: Strong antibiotic prophylaxis recommended. Close monitoring required."
    default:
        return "Invalid score range."
    }
}
