//
//  DoctorModel.swift
//  Renal Guard
//import Foundation

// MARK: - Doctor Model
struct DoctorModel: Identifiable, Codable {
    let user_id: Int
    let name: String
    let email: String
    let phone: String
    let specialization: String?
    let doctor_no: String?

    var id: Int { user_id }
}

// MARK: - API Response
struct DoctorResponse: Codable {
    let status: String
    let count: Int
    let doctors: [DoctorModel]
}

