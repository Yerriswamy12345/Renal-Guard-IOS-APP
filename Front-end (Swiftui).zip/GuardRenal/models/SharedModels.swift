import Foundation

struct DeleteResponse: Codable {
    let success: Bool
    let message: String
}
