import Foundation

struct DaySchedule: Identifiable, Codable {
    let scheduleId: Int
    let doctorId: String
    let date: String
    let startTime: String
    let endTime: String
    let slotDuration: Int
    let maxPatients: Int
    let bookedCount: Int
    let status: String
    let remainingSlots: Int
    
    var id: Int { scheduleId }

    enum CodingKeys: String, CodingKey {
        case scheduleId = "schedule_id"
        case doctorId = "doctor_id"
        case date
        case startTime = "start_time"
        case endTime = "end_time"
        case slotDuration = "slot_duration"
        case maxPatients = "max_patients"
        case bookedCount = "booked_count"
        case status
        case remainingSlots = "remaining_slots"
    }
}
