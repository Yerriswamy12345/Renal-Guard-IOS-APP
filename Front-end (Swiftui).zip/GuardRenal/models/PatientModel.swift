import Foundation

struct PatientListResponse: Codable {
    let status: String
    let count: Int
    let patients: [PatientModel]
}

struct PatientModel: Codable, Identifiable {
    var id: String { user_id }

    let user_id: String
    let name: String
    let email: String
    let phone: String
    let age: String
    let gender: String
    let patient_no: String
}
