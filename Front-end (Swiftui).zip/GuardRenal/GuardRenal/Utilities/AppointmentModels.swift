import Foundation

// MARK: - Slot Status Enum
enum SlotStatus: String, Codable {
    case available
    case booked
    case cancelled
    case attended
    case missed
}

// MARK: - Day Schedule Model (Moved to DaySchedule.swift)

// MARK: - Doctor Schedule Model
struct DoctorSchedule: Identifiable, Codable {
    let id: Int
    let doctorId: String
    let scheduleDate: String
    let startTime: String
    let endTime: String
    let totalSlots: Int
    let remainingSlots: Int
    let status: String
    
    enum CodingKeys: String, CodingKey {
        case id = "schedule_id"
        case doctorId = "doctor_id"
        case scheduleDate = "schedule_date"
        case startTime = "start_time"
        case endTime = "end_time"
        case totalSlots = "total_slots"
        case remainingSlots = "remaining_slots"
        case status
    }
}

// MARK: - Time Slot Model
struct TimeSlot: Identifiable, Codable {
    let id: Int
    let slotStartTime: String
    let slotEndTime: String
    let slotStatus: String
    
    enum CodingKeys: String, CodingKey {
        case id = "slot_id"
        case slotStartTime = "slot_start_time"
        case slotEndTime = "slot_end_time"
        case slotStatus = "slot_status"
    }
}

// MARK: - Schedule with Slots
struct ScheduleWithSlots: Identifiable, Codable {
    let scheduleId: Int
    let scheduleDate: String
    let startTime: String
    let endTime: String
    let totalSlots: Int
    let remainingSlots: Int
    let status: String
    let availableSlots: [TimeSlot]
    
    var id: Int { scheduleId }
    
    enum CodingKeys: String, CodingKey {
        case scheduleId = "schedule_id"
        case scheduleDate = "schedule_date"
        case startTime = "start_time"
        case endTime = "end_time"
        case totalSlots = "total_slots"
        case remainingSlots = "remaining_slots"
        case status
        case availableSlots = "available_slots"
    }
}

// MARK: - Booked Appointment Model
struct BookedAppointment: Identifiable, Codable {
    let id: Int
    let patientId: Int?
    let doctorId: String?
    let doctorName: String?
    let patientName: String?
    let scheduleDate: String
    let slotTime: String
    let bookingTime: String
    let appointmentStatus: String
    let attendanceStatus: String?
    
    enum CodingKeys: String, CodingKey {
        case id = "appointment_id"
        case patientId = "patient_id"
        case doctorId = "doctor_id"
        case doctorName = "doctor_name"
        case patientName = "patient_name"
        case scheduleDate = "schedule_date"
        case slotTime = "slot_time"
        case bookingTime = "booking_time"
        case appointmentStatus = "appointment_status"
        case attendanceStatus = "attendance_status"
    }
}

// MARK: - Doctor with Schedule
struct DoctorWithSchedule: Identifiable, Codable {
    let doctorId: String
    let name: String
    let email: String
    let phone: String
    let specialization: String?
    let doctorNo: String?
    
    var id: String { doctorId }
    
    enum CodingKeys: String, CodingKey {
        case doctorId = "doctor_id"
        case name
        case email
        case phone
        case specialization
        case doctorNo = "doctor_no"
    }
}

// MARK: - API Response Models

struct ScheduleResponse: Codable {
    let success: Bool
    let message: String?
    let data: ScheduleData?
}

struct ScheduleData: Codable {
    let scheduleId: Int
    let doctorId: String
    let scheduleDate: String
    let startTime: String
    let endTime: String
    let totalSlots: Int
    let slotsGenerated: Int
    let status: String
    
    enum CodingKeys: String, CodingKey {
        case scheduleId = "schedule_id"
        case doctorId = "doctor_id"
        case scheduleDate = "schedule_date"
        case startTime = "start_time"
        case endTime = "end_time"
        case totalSlots = "total_slots"
        case slotsGenerated = "slots_generated"
        case status
    }
}

struct DoctorsWithSchedulesResponse: Codable {
    let success: Bool
    let count: Int
    let doctors: [DoctorWithSchedule]
}

struct AvailableSlotsResponse: Codable {
    let success: Bool
    let date: String?
    let slots: [String]
    
    enum CodingKeys: String, CodingKey {
        case success
        case date
        case slots
    }
}

struct BookingResponse: Codable {
    let success: Bool
    let message: String
}

struct BookingData: Codable {
    let appointmentId: Int
    let patientId: Int
    let doctorId: String
    let doctorName: String
    let scheduleDate: String
    let slotTime: String
    let bookingTime: String
    
    enum CodingKeys: String, CodingKey {
        case appointmentId = "appointment_id"
        case patientId = "patient_id"
        case doctorId = "doctor_id"
        case doctorName = "doctor_name"
        case scheduleDate = "schedule_date"
        case slotTime = "slot_time"
        case bookingTime = "booking_time"
    }
}

struct DaySchedulesResponse: Codable {
    let success: Bool
    let doctorId: String
    let schedules: [DaySchedule]
    
    enum CodingKeys: String, CodingKey {
        case success
        case doctorId = "doctor_id"
        case schedules
    }
}

struct AppointmentsResponse: Codable {
    let success: Bool
    let count: Int
    let appointments: [BookedAppointment]
}
