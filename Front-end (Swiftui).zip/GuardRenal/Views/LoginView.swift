import SwiftUI

struct LoginView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var selectedRole: String = ""

    // 👁 Password visibility
    @State private var isPasswordVisible = false

    // Navigation states
    @State private var goToAdmin = false
    @State private var goToDoctor = false
    @State private var goToPatient = false

    // Alert
    @State private var showAlert = false
    @State private var alertMessage = ""

    // Stored Data
    @AppStorage("fullname") var isname: String = ""
    @AppStorage("email") var myemail: String = ""
    @AppStorage("phone") var mymobile: String = ""
    @AppStorage("user_id") var storedUserId: Int = 0
    @AppStorage("login") var islogged: Bool = false

    // Focus state
    @FocusState private var focusedField: Field?

    enum Field {
        case email, password
    }

    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()

            VStack(spacing: 28) {

                // -------- LOGO ----------
                VStack(spacing: 16) {
                    Image("Image 2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120)

                    Text("Renal Guard")
                        .font(.system(size: 30, weight: .semibold))
                        .foregroundColor(Color(red: 0/255, green: 100/255, blue: 100/255))
                }
                .padding(.top, 40)

                // -------- Heading ----------
                VStack(spacing: 6) {
                    Text("Login")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(.black)

                    HStack(spacing: 3) {
                        Text("Don't have an account?")
                            .foregroundColor(.black)

                        NavigationLink(destination: Signup()) {
                            Text("Sign up")
                                .foregroundColor(.blue)
                                .font(.system(size: 18, weight: .semibold))
                        }
                    }
                }

                // -------- Email ----------
                HStack {
                    Image(systemName: "person.fill")
                        .foregroundColor(.black)

                    TextField("", text: $email)
                        .foregroundColor(.black)
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)
                        .focused($focusedField, equals: .email)
                        .placeholderText(when: email.isEmpty) {
                            Text("Email Address")
                                .foregroundColor(.black.opacity(0.5))
                        }
                }
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 2))
                .padding(.horizontal, 28)

                // -------- Password (👁 Eye Added) ----------
                HStack {
                    Image(systemName: "lock.fill")
                        .foregroundColor(.black)

                    Group {
                        if isPasswordVisible {
                            TextField("", text: $password)
                        } else {
                            SecureField("", text: $password)
                        }
                    }
                    .foregroundColor(.black)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .focused($focusedField, equals: .password)
                    .placeholderText(when: password.isEmpty) {
                        Text("Password")
                            .foregroundColor(.black.opacity(0.5))
                    }

                    Button(action: {
                        isPasswordVisible.toggle()
                    }) {
                        Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.black.opacity(0.7))
                    }
                }
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 2))
                .padding(.horizontal, 28)

                // -------- Roles ----------
                HStack(spacing: 25) {
                    RoleButton(title: "Doctor", selectedRole: $selectedRole)
                    RoleButton(title: "Patient", selectedRole: $selectedRole)
                    RoleButton(title: "Admin", selectedRole: $selectedRole)
                }
                .padding(.top, 10)

                // -------- LOGIN ----------
                Button(action: {
                    focusedField = nil
                    loginUser()
                }) {
                    Text("Login")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Color(red: 0/255, green: 110/255, blue: 100/255))
                        .cornerRadius(35)
                        .padding(.horizontal, 40)
                        .shadow(radius: 4)
                }
                .padding(.bottom, 60)
            }
            .padding(.top, -100)
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Login"),
                message: Text(alertMessage),
                dismissButton: .default(Text("OK"))
            )
        }

        // -------- Navigation ----------
        .navigationDestination(isPresented: $goToAdmin) { AdminDashboard() }
        .navigationDestination(isPresented: $goToDoctor) { DoctorDashboard() }
        .navigationDestination(isPresented: $goToPatient) {
            PatientDashboard(patientId: storedUserId)
        }
    }

    // MARK: - API CALL
    func loginUser() {
        guard !selectedRole.isEmpty else {
            alertMessage = "Please select a role"
            showAlert = true
            return
        }

        let parameters: [String: Any] = [
            "email": email,
            "password": password,
            "role": selectedRole
        ]

        NetworkManager.shared.postRequest(
            endpoint: "login.php",
            parameters: parameters,
            responseType: LoginResponse.self
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.success, let user = response.data?.user {
                        if user.role.lowercased() == selectedRole.lowercased() {
                            islogged = true
                            storedUserId = user.id
                            isname = user.name
                            myemail = user.email
                            mymobile = user.phone

                            switch user.role.lowercased() {
                            case "doctor": goToDoctor = true
                            case "patient": goToPatient = true
                            case "admin": goToAdmin = true
                            default:
                                alertMessage = "Unknown role"
                                showAlert = true
                            }
                        } else {
                            alertMessage = "Role mismatch"
                            showAlert = true
                        }
                    } else {
                        alertMessage = response.message ?? "Login failed"
                        showAlert = true
                    }
                case .failure(let error):
                    alertMessage = error.localizedDescription
                    showAlert = true
                }
            }
        }
    }
}

// MARK: - Models
// MARK: - Models
struct LoginResponse: Codable {
    let success: Bool
    let message: String?
    let data: LoginData?
}

struct LoginData: Codable {
    let user: LoginUser?
}

struct LoginUser: Codable {
    let id: Int
    let name: String
    let email: String
    let phone: String
    let role: String
}



// MARK: - Role Button
struct RoleButton: View {
    let title: String
    @Binding var selectedRole: String
    
    var body: some View {
        Button(action: { selectedRole = title }) {
            HStack {
                Circle()
                    .strokeBorder(Color.gray, lineWidth: 2)
                    .background(Circle().fill(selectedRole == title ? Color.teal : Color.clear))
                    .frame(width: 20, height: 20)
                
                Text(title)
                    .foregroundColor(.black)
            }
        }
    }
}



// MARK: - Placeholder Text Extension
extension View {
    func placeholderText<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content
    ) -> some View {
        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
}


#Preview {
    LoginView()
}
