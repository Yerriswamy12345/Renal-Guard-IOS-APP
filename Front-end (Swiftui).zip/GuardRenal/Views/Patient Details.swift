import SwiftUI

struct PatientDetails: View {
    
    // ✅ Accept patient data
    let patient: DoctorPatientModel
    
    @State private var name: String
    @State private var age: String
    @State private var gender: String
    @State private var email: String
    @State private var mobile: String
    @State private var patientID: String
    
    // ✅ Initialize with patient data
    init(patient: DoctorPatientModel) {
        self.patient = patient
        _name = State(initialValue: patient.name ?? "")
        _age = State(initialValue: patient.age != nil ? String(patient.age!) : "")
        _gender = State(initialValue: patient.gender ?? "")
        _email = State(initialValue: patient.email ?? "")
        _mobile = State(initialValue: patient.phone ?? "")
        _patientID = State(initialValue: patient.patientNo)
    }
    
    @Environment(\.dismiss) private var dismiss

    // ✅ Navigation triggers
    @State private var goToPatientData = false
    @State private var goToDoctorDashboard = false
    
    // ✅ Save functionality
    @State private var isSaving = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        ZStack {
            Color.white
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                
                // ✅ Custom Top Bar (with Back + House)
                ZStack(alignment: .center) {
                    Color(red: 0/255, green: 128/255, blue: 128/255)
                    
                    HStack {
                        // 🔙 Back button → PatientData
                        Button(action: {
                            dismiss()
                        }) {
                            HStack(spacing: 4) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.white)
                                    .padding(.top, 50)
                                
                                Text("Back")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.white)
                                    .padding(.top, 50)
                            }
                        }
                        .padding(.leading, 16)
                        
                        Spacer()
                        
                        // 🏠 House Button → DoctorDashboard
                        // Note: Pushing DoctorDashboard here creates a loop. 
                        // For now, we keep it but typically this should unwind the stack.
                        Button(action: {
                            goToDoctorDashboard = true
                        }) {
                            Image(systemName: "house.fill")
                                .font(.system(size: 24))
                                .foregroundColor(.white)
                                .padding(.top, 45)
                                .padding(.trailing, 16)
                        }
                    }
                    
                    // 🩺 Title
                    Text("Patient Details")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 50)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 100)
                .ignoresSafeArea(edges: .top)
                
                // ✅ Form Fields
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Name")
                            .font(.headline)
                            .foregroundColor(.black)
                        TextField("", text: $name)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(red: 230/255, green: 245/255, blue: 250/255))
                            .cornerRadius(10)
                    }
                    
                    HStack(spacing: 15) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Age")
                                .font(.headline)
                                .foregroundColor(.black)
                            TextField("", text: $age)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color(red: 230/255, green: 245/255, blue: 250/255))
                                .cornerRadius(10)
                                .keyboardType(.numberPad)
                        }
                        
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Gender")
                                .font(.headline)
                                .foregroundColor(.black)
                            TextField("", text: $gender)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color(red: 230/255, green: 245/255, blue: 250/255))
                                .cornerRadius(10)
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("E-mail Id")
                            .font(.headline)
                            .foregroundColor(.black)
                        TextField("", text: $email)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(red: 230/255, green: 245/255, blue: 250/255))
                            .cornerRadius(10)
                            .keyboardType(.emailAddress)
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Mobile Number")
                            .font(.headline)
                            .foregroundColor(.black)
                        TextField("", text: $mobile)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(red: 230/255, green: 245/255, blue: 250/255))
                            .cornerRadius(10)
                            .keyboardType(.numberPad)
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Patient ID")
                            .font(.headline)
                            .foregroundColor(.black)
                        TextField("", text: $patientID)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(red: 230/255, green: 245/255, blue: 250/255))
                            .cornerRadius(10)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 10)
                
                Spacer()
                
                // ✅ Save Button
                VStack {
                    Button(action: {
                        updatePatient()
                    }) {
                        Text(isSaving ? "Saving..." : "Save")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .font(.headline)
                            .foregroundColor(.white)
                            .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                            .cornerRadius(30)
                            .padding(.horizontal, 40)
                    }
                    .disabled(isSaving)
                    .padding(.bottom, 20)
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .alert(alertMessage, isPresented: $showAlert) {
            Button("OK", role: .cancel) {}
        }
        .navigationDestination(isPresented: $goToDoctorDashboard) {
            DoctorDashboard() // This creates circular navigation, but left as is per scope to just fix Back button flow.
        }
        .navigationDestination(isPresented: $goToPatientData) {
            // PatientData(patient: patient) // Circular, removed.
             EmptyView()
        }
    }
    
    // MARK: - Update Patient API
    func updatePatient() {
        isSaving = true
        
        let parameters: [String: Any] = [
            "patient_id": patient.patientNo,
            "name": name,
            "age": age,
            "gender": gender,
            "email": email,
            "mobile": mobile
        ]
        
        NetworkManager.shared.postRequest(endpoint: "update_patient.php", parameters: parameters, responseType: SaveResponse.self) { result in
            DispatchQueue.main.async {
                self.isSaving = false
                switch result {
                case .success(let response):
                    alertMessage = response.success ? "Patient updated successfully!" : response.message
                    showAlert = true
                case .failure(let error):
                    alertMessage = "Error: \(error.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }
}

struct SaveResponse: Codable {
    let success: Bool
    let message: String
}

#Preview {
    PatientDetails(patient: DoctorPatientModel(
        patient_id: "P001",
        user_id: 10,
        name: "Meena",
        email: "meena20@gmail.com",
        phone: "1234567890",
        age: 20,
        gender: "Female",
        latest_score: 11,
        latest_date: "2025-10-28"
    ))
}
