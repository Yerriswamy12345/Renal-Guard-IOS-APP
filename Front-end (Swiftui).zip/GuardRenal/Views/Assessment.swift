import SwiftUI

struct Assessment: View {
    @State private var goToAddPatient = false
    @State private var navigateToRiskScore = false

    // ✅ Accept patient_id and patient_email
    let patientId: String
    let patientEmail: String
    
    // ✅ Doctor Email from AppStorage
    @AppStorage("email") private var doctorEmail: String = ""
    @Environment(\.dismiss) private var dismiss

    // MARK: - All Question States
    @State private var comorbidities = Set<String>()
    @State private var ageSelection: String? = nil
    @State private var lineAttempts: String? = nil
    @State private var duration: String? = nil
    @State private var healthcareSetup: String? = nil
    @State private var skinIntegrity: String? = nil
    @State private var linePlacement: String? = nil
    @State private var dialysisFrequency: String? = nil
    @State private var chronicSteroid: String? = nil
    @State private var previousAntibiotic: String? = nil
    @State private var postLineSymptoms: String? = nil
    @State private var stageOfAKI: String? = nil

    // MARK: - FINAL SCORE
    @State private var finalScore: Int = 0
    
    // ✅ API States
    @State private var isSavingScore = false
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.white.ignoresSafeArea()

            VStack(spacing: 0) {

                // ---------------- TOP BAR ----------------
                ZStack(alignment: .center) {
                                   Color(red: 0/255, green: 128/255, blue: 128/255)

                                   Text("Patient Assessment")
                                       .font(.system(size: 26, weight: .bold))
                                       .foregroundColor(.white)
                                       .padding(.top, 40)
                               }
                               .frame(maxWidth: .infinity)
                               .frame(height: 100)
                               .ignoresSafeArea(edges: .top)

                // ------------- FORM SCROLLVIEW --------------
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 20) {
                        section1_Comorbidities()
                        section2_Age()
                        section3_LineAttempts()
                        section4_Duration()
                        section5_HealthcareSetup()
                        section6_SkinIntegrity()
                        section7_LinePlacement()
                        section8_DialysisFrequency()
                        section9_ChronicSteroid()
                        section10_PreviousAntibiotic()
                        section11_PostLineSymptoms()
                        section12_StageOfAKI()
                    }
                    .padding(.top, 10)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 80)
                }
            }

            // ------------------ CALCULATE BUTTON ------------------
            VStack {
                Divider().padding(.bottom, 4)

                Button(action: {
                    finalScore = calculateTotalScore()
                    saveScoreToAPI()  // ✅ Save to backend first
                }) {
                    HStack {
                        if isSavingScore {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        }
                        Text(isSavingScore ? "Saving..." : "Calculate")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.white)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                    .cornerRadius(30)
                    .padding(.horizontal, 20)
                }
                .disabled(isSavingScore)
                .buttonStyle(.plain)
                .padding(.bottom, 20)
                .background(Color.white.opacity(0.9))
            }
            .ignoresSafeArea(edges: .bottom)
        }
        .toolbar(.hidden, for: .navigationBar)

        // ----------------- NAVIGATION -------------------
        .navigationDestination(isPresented: $navigateToRiskScore) {
            RiskScore(patientScore: finalScore, patientId: patientId, patientEmail: patientEmail)
        }

        .navigationDestination(isPresented: $goToAddPatient) {
            AddPatient()
        }
        
        // ✅ Alert for errors
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Assessment"),
                message: Text(alertMessage),
                dismissButton: .default(Text("OK"))
            )
        }
    }

    // MARK: - SECTION BOX (ADAPTIVE)
    func sectionBox<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            content()
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(red: 224/255, green: 245/255, blue: 245/255))
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.2)))
    }

    // -------------------------- SECTIONS BELOW (Original UI) ----------------------
    @ViewBuilder
    func section1_Comorbidities() -> some View {
        let options = [
            "Diabetes (1 point)",
            "Hypertension (1 point)",
            "Cancer (1 point)",
            "Smoker (1 point)",
            "Alcoholic (1 point)",
            "Any other disease (1 point)"
        ]
        sectionBox {
            Text("1. Comorbidities (0–6 points)")
                .font(.system(size: 18, weight: .semibold))

            VStack(alignment: .leading, spacing: 8) {
                ForEach(options, id: \.self) { option in
                    HStack {
                        Image(systemName: comorbidities.contains(option) ? "largecircle.fill.circle" : "circle")
                            .resizable()
                            .frame(width: 22, height: 22)
                            .foregroundColor(comorbidities.contains(option)
                                             ? Color(red: 0/255, green: 128/255, blue: 128/255)
                                             : .gray)
                            .onTapGesture { toggleSelection(option) }

                        Text(option)
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                            .onTapGesture { toggleSelection(option) }
                    }
                }
            }
        }
    }

    private func toggleSelection(_ option: String) {
        if comorbidities.contains(option) {
            comorbidities.remove(option)
        } else {
            comorbidities.insert(option)
        }
    }

    @ViewBuilder func section2_Age() -> some View {
        sectionBox {
            Text("2. Age (0–2 points)").font(.headline)
            radioGroup(options: ["Above 55 years (2 points)", "Below 55 years (0 points)"], selection: $ageSelection)
        }
    }

    @ViewBuilder func section3_LineAttempts() -> some View {
        sectionBox {
            Text("3. Multiple attempts for line insertion (0–1 point)").font(.headline)
            radioGroup(options: ["Yes (1 point)", "No (0 points)"], selection: $lineAttempts)
        }
    }

    @ViewBuilder func section4_Duration() -> some View {
        sectionBox {
            Text("4. Duration of line (1–3 points)").font(.headline)
            radioGroup(options: ["1 week (1 point)", "2 weeks (2 points)", "3 weeks (3 points)"], selection: $duration)
        }
    }

    @ViewBuilder func section5_HealthcareSetup() -> some View {
        sectionBox {
            Text("5. Healthcare Setup (1–2 points)").font(.headline)
            radioGroup(options: ["Private setup with an aseptic environment (1 point)", "Government hospital (2 points)"], selection: $healthcareSetup)
        }
    }

    @ViewBuilder func section6_SkinIntegrity() -> some View {
        sectionBox {
            Text("6. Skin Integrity (0–1 point)").font(.headline)
            radioGroup(options: ["Any dermatitis/infection at the site (1 point)", "Normal skin (0 points)"], selection: $skinIntegrity)
        }
    }

    @ViewBuilder func section7_LinePlacement() -> some View {
        sectionBox {
            Text("7. Line Placement by (0–1 point)").font(.headline)
            radioGroup(options: ["Doctor (0 points)", "Paramedical staff (1 point)"], selection: $linePlacement)
        }
    }

    @ViewBuilder func section8_DialysisFrequency() -> some View {
        sectionBox {
            Text("8. Dialysis Frequency (1–3 points)").font(.headline)
            radioGroup(options: ["Less than 3 sessions/week (1 point)", "Less than 6 sessions/week (2 points)", "Less than 9 sessions/week (3 points)"], selection: $dialysisFrequency)
        }
    }

    @ViewBuilder func section9_ChronicSteroid() -> some View {
        sectionBox {
            Text("9. Chronic Steroid/Immunosuppressive Drugs (0–2 points)").font(.headline)
            radioGroup(options: ["Yes (2 points)", "No (0 points)"], selection: $chronicSteroid)
        }
    }

    @ViewBuilder func section10_PreviousAntibiotic() -> some View {
        sectionBox {
            Text("10. Previous Antibiotic Use (0–1 point)").font(.headline)
            radioGroup(options: ["Yes (1 point)", "No (0 points)"], selection: $previousAntibiotic)
        }
    }

    @ViewBuilder func section11_PostLineSymptoms() -> some View {
        sectionBox {
            Text("11. Post-Line Symptoms (0–2 points)").font(.headline)
            radioGroup(options: ["Fever, swelling, pain, or discharge after line placement (2 points)", "No symptoms (0 points)"], selection: $postLineSymptoms)
        }
    }

    @ViewBuilder func section12_StageOfAKI() -> some View {
        sectionBox {
            Text("12. Stage of AKI/CKD (0–1 point)").font(.headline)
            radioGroup(options: ["AKI (0 points)", "CKD (1 point)"], selection: $stageOfAKI)
        }
    }

    // MARK: - RADIO GROUP (same UI)
    func radioGroup(options: [String], selection: Binding<String?>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(options, id: \.self) { option in
                HStack {
                    Image(systemName: selection.wrappedValue == option ? "largecircle.fill.circle" : "circle")
                        .resizable()
                        .frame(width: 22, height: 22)
                        .foregroundColor(selection.wrappedValue == option
                                         ? Color(red: 0/255, green: 128/255, blue: 128/255)
                                         : .gray)
                        .onTapGesture {
                            withAnimation(.easeInOut(duration: 0.1)) {
                                selection.wrappedValue = option
                            }
                        }

                    Text(option)
                        .font(.system(size: 16))
                        .foregroundColor(.black)
                        .onTapGesture {
                            withAnimation(.easeInOut(duration: 0.1)) {
                                selection.wrappedValue = option
                            }
                        }
                }
            }
        }
    }

    // MARK: - SAVE SCORE TO API
    func saveScoreToAPI() {
        isSavingScore = true
        
        let parameters: [String: Any] = [
            "patient_id": patientId,
            "doctor_email": doctorEmail,
            "patient_email": patientEmail,
            "score": finalScore,
            "line_duration": duration ?? "", // assuming duration string matches logic or needs converting
            // wait, PHP saves 'line_duration'. 'duration' state is "1 week (1 point)" etc.
            // Ideally we should send the raw value.
            // But let's send what we have for now, or clean it.
            // The PHP script doesn't validate 'line_duration' format.
            "stage": stageOfAKI ?? ""
        ]
        
        NetworkManager.shared.postRequest(endpoint: "save_assessment.php", parameters: parameters, responseType: SaveAssessmentResponse.self) { result in
            DispatchQueue.main.async {
                isSavingScore = false
                switch result {
                case .success(let response):
                    if response.success {
                        navigateToRiskScore = true
                    } else {
                        alertMessage = response.message
                        showAlert = true
                    }
                case .failure(let error):
                    alertMessage = "Error: \(error.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }

    // MARK: - FINAL SCORE CALCULATION
    func calculateTotalScore() -> Int {
        var score = 0

        score += comorbidities.count
        if ageSelection == "Above 55 years (2 points)" { score += 2 }
        if lineAttempts == "Yes (1 point)" { score += 1 }

        if duration == "1 week (1 point)" { score += 1 }
        if duration == "2 weeks (2 points)" { score += 2 }
        if duration == "3 weeks (3 points)" { score += 3 }

        if healthcareSetup == "Private setup with an aseptic environment (1 point)" { score += 1 }
        if healthcareSetup == "Government hospital (2 points)" { score += 2 }

        if skinIntegrity == "Any dermatitis/infection at the site (1 point)" { score += 1 }

        if linePlacement == "Paramedical staff (1 point)" { score += 1 }

        if dialysisFrequency == "Less than 3 sessions/week (1 point)" { score += 1 }
        if dialysisFrequency == "Less than 6 sessions/week (2 points)" { score += 2 }
        if dialysisFrequency == "Less than 9 sessions/week (3 points)" { score += 3 }

        if chronicSteroid == "Yes (2 points)" { score += 2 }
        if previousAntibiotic == "Yes (1 point)" { score += 1 }
        if postLineSymptoms == "Fever, swelling, pain, or discharge after line placement (2 points)" { score += 2 }

        if stageOfAKI == "CKD (1 point)" { score += 1 }

        return score
    }
}

struct SaveAssessmentResponse: Codable {
    let success: Bool
    let message: String
}

#Preview {
    Assessment(patientId: "PAT001", patientEmail: "test@example.com")
}
