import SwiftUI

struct AddSchedule: View {

    @StateObject private var viewModel = ScheduleViewModel()
    @AppStorage("user_id") private var userId: Int = 0
    @AppStorage("email") private var doctorEmail: String = ""

    // MARK: - States
    @State private var selectedDate: Date? = nil
    @State private var startTime: Date? = nil
    @State private var endTime: Date? = nil

    @State private var showDatePicker = false
    @State private var showStartPicker = false
    @State private var showEndPicker = false

    // ✅ Navigation
    @State private var goToAppointments = false
    @State private var goToDoctorDashboard = false

    var body: some View {
        NavigationStack {
            ZStack {
                // ✅ Background
                Color.white
                    .ignoresSafeArea()

                VStack(spacing: 0) {

                    // ✅ Top Bar
                    ZStack(alignment: .center) {
                        Color(red: 0/255, green: 128/255, blue: 128/255)

                        HStack {
                            // 🔙 Back → Appointments
                            Button(action: {
                                goToAppointments = true
                            }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "chevron.left")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)

                                    Text("Back")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)
                                }
                            }
                            .padding(.leading, 16)

                            Spacer()
                        }

                        Text("Add Schedule")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.top, 40)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 100)
                    .ignoresSafeArea(edges: .top)
                    .padding(.top, -20)

                    // ✅ Main Content
                    VStack(spacing: 25) {

                        // 📅 Select Date
                        scheduleButton(
                            title: "Select Date",
                            value: formattedDate(from: selectedDate)
                        ) {
                            showDatePicker.toggle()
                        }

                        // ⏰ Start Time
                        scheduleButton(
                            title: "Start Time",
                            value: formattedTime(from: startTime)
                        ) {
                            startTime = Date()
                            showStartPicker.toggle()
                        }

                        // ⏰ End Time
                        scheduleButton(
                            title: "End Time",
                            value: formattedTime(from: endTime)
                        ) {
                            showEndPicker.toggle()
                        }

                        // ✅ Save Button
                        Button(action: {
                            Task {
                                await saveSchedule()
                            }
                        }) {
                            HStack {
                                if viewModel.isLoading {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                }

                                Text(viewModel.isLoading ? "Saving..." : "Save Schedule")
                                    .font(.system(size: 20, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(
                                (selectedDate != nil && startTime != nil && endTime != nil && !viewModel.isLoading)
                                ? Color(red: 0/255, green: 128/255, blue: 128/255)
                                : Color.gray
                            )
                            .cornerRadius(35)
                        }
                        .disabled(selectedDate == nil || startTime == nil || endTime == nil || viewModel.isLoading)
                        .padding(.top, 10)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)

                    Spacer()
                }

                // ✅ Date Picker
                if showDatePicker {
                    customPickerPopup(
                        title: "Select Date",
                        selection: Binding(
                            get: { selectedDate ?? Date() },
                            set: { selectedDate = $0 }
                        ),
                        components: .date,
                        isVisible: $showDatePicker,
                        minimumDate: Calendar.current.startOfDay(for: Date())
                    )
                }

                // ✅ Start Time Picker
                if showStartPicker {
                    customPickerPopup(
                        title: "Select Start Time",
                        selection: Binding(
                            get: { startTime ?? Date() },
                            set: { startTime = $0 }
                        ),
                        components: .hourAndMinute,
                        isVisible: $showStartPicker,
                        minimumDate: Date()
                    )
                }

                // ✅ End Time Picker
                if showEndPicker {
                    customPickerPopup(
                        title: "Select End Time",
                        selection: Binding(
                            get: { endTime ?? Date() },
                            set: { endTime = $0 }
                        ),
                        components: .hourAndMinute,
                        isVisible: $showEndPicker,
                        minimumDate: startTime ?? Date()
                    )
                }
            }
            .toolbar(.hidden, for: .navigationBar)

            // ✅ Navigation Destinations
            .navigationDestination(isPresented: $goToAppointments) {
                Appointments()
                    .navigationBarBackButtonHidden(true)
            }

            .navigationDestination(isPresented: $goToDoctorDashboard) {
                DoctorDashboard()
                    .navigationBarBackButtonHidden(true)
            }

            // ✅ Success Alert → Doctor Dashboard
            .alert("Success", isPresented: $viewModel.showSuccess) {
                Button("OK") {
                    viewModel.resetSuccess()
                    goToDoctorDashboard = true
                }
            } message: {
                Text(viewModel.successMessage ?? "Schedule created successfully")
            }

            // ❌ Error Alert
            .alert("Error", isPresented: .constant(viewModel.errorMessage != nil)) {
                Button("OK") {
                    viewModel.resetError()
                }
            } message: {
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                }
            }
        }
    }

    // MARK: - Reusable Button
    func scheduleButton(title: String, value: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Text(value.isEmpty ? title : value)
                    .foregroundColor(value.isEmpty ? .gray : .black)
                Spacer()
            }
            .padding()
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.black, lineWidth: 1)
            )
        }
    }

    // MARK: - Picker Popup
    func customPickerPopup(
        title: String,
        selection: Binding<Date>,
        components: DatePickerComponents,
        isVisible: Binding<Bool>,
        minimumDate: Date
    ) -> some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()
                .onTapGesture { isVisible.wrappedValue = false }

            VStack(spacing: 15) {
                Text(title)
                    .font(.system(size: 22, weight: .bold))

                DatePicker("", selection: selection, in: minimumDate..., displayedComponents: components)
                    .labelsHidden()
                    .datePickerStyle(.wheel)

                HStack {
                    Button("Cancel") { isVisible.wrappedValue = false }
                    Button("OK") { isVisible.wrappedValue = false }
                        .fontWeight(.semibold)
                }
            }
            .padding()
            .background(Color.white)
            .cornerRadius(16)
        }
    }

    // MARK: - Formatters
    func formattedDate(from date: Date?) -> String {
        guard let date else { return "" }
        let f = DateFormatter()
        f.dateFormat = "MMM d, yyyy"
        return f.string(from: date)
    }

    func formattedTime(from date: Date?) -> String {
        guard let date else { return "" }
        let f = DateFormatter()
        f.timeStyle = .short
        return f.string(from: date)
    }

    // MARK: - API Call
    private func saveSchedule() async {
        guard let date = selectedDate,
              let start = startTime,
              let end = endTime else { return }

        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd"

        let tf = DateFormatter()
        tf.dateFormat = "HH:mm:ss"

        await viewModel.createSchedule(
            doctorEmail: doctorEmail,
            date: df.string(from: date),
            startTime: tf.string(from: start),
            endTime: tf.string(from: end)
        )
    }
}

#Preview {
    AddSchedule()
}
