import SwiftUI

struct ScoreEntry: Identifiable {
    let id = UUID()
    let date: String
    let score: Int
}

struct ScoreDetails: View {
    @Environment(\.dismiss) private var dismiss
    
    // ✅ Accept patient_id
    let patientId: String
    var patientEmail: String? // Added optional email
    
    // ✅ Dynamic Score Data from API
    @State private var scores: [ScoreModel] = []
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()
            
            VStack(spacing: 15) {
                
                // ✅ Custom Top Bar (only custom back button)
                ZStack(alignment: .center) {
                    Color(red: 0/255, green: 128/255, blue: 128/255)
                    
                    HStack {
                        // 🔙 Custom Back Button
                        Button(action: { dismiss() }) {
                            HStack(spacing: 4) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.white)
                                    .padding(.top, 40)
                                
                                Text("Back")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.white)
                                    .padding(.top, 40)
                            }
                        }
                        .padding(.leading, 16)
                        
                        Spacer()
                    }
                    
                    // 🩺 Title
                    Text("Patient Score")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 40)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 100)
                .ignoresSafeArea(edges: .top)
                
                // ✅ Table Header
                HStack {
                    Text("Date")
                        .font(.headline)
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.leading, 25)
                    
                    Text("Score")
                        .font(.headline)
                        .foregroundColor(.black)
                        .frame(width: 80, alignment: .trailing)
                        .padding(.trailing, 25)
                }
                .frame(height: 50)
                .background(Color(red: 0/255, green: 210/255, blue: 196/255))
                .cornerRadius(10)
                .padding(.horizontal, 10)
                
                // ✅ Scrollable Score List
                ScrollView {
                    if isLoading {
                        ProgressView("Loading scores...")
                            .padding()
                    } else if let error = errorMessage {
                        Text(error)
                            .foregroundColor(.red)
                            .padding()
                    } else if scores.isEmpty {
                        Text("No assessments yet")
                            .foregroundColor(.gray)
                            .padding()
                    } else {
                        VStack(spacing: 15) {
                            ForEach(scores) { entry in
                                HStack {
                                    Text(entry.formattedDate)
                                        .font(.system(size: 18))
                                        .foregroundColor(.black)
                                        .padding(.leading, 25)
                                    
                                    Spacer()
                                    
                                    Text("\(entry.score)")
                                        .font(.system(size: 18))
                                        .foregroundColor(.black)
                                        .padding(.trailing, 25)
                                }
                                .frame(height: 70)
                                .background(
                                    RoundedRectangle(cornerRadius: 18)
                                        .fill(Color.white)
                                        .shadow(color: .gray.opacity(0.2), radius: 1, x: 0, y: 1)
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: 18)
                                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                )
                                .padding(.horizontal, 16)
                            }
                        }
                        .padding(.top, 10)
                    }
                }
                
                // ✅ Latest Recommendation Section
                VStack(alignment: .leading, spacing: 8) {
                    Text("Latest Recommendation")
                        .font(.headline)
                        .foregroundColor(.black)
                    
                    if let latestScore = scores.first?.score {
                        Text(getRiskRecommendation(score: latestScore))
                            .font(.body)
                            .foregroundColor(.black)
                    } else {
                        Text("No assessment available yet.")
                            .font(.body)
                            .foregroundColor(.gray)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                
                Spacer()
                
                // ✅ Bottom Back Button
                Button(action: { dismiss() }) {
                    Text("Back")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color(red: 0/255, green: 128/255, blue: 128/255), lineWidth: 4)
                        )
                        .cornerRadius(30)
                        .padding(.horizontal, 40)
                }
                .padding(.bottom, 25)
            }
        }
        // 🚫 Hide system navigation bar & back button
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .onAppear {
            fetchScores()
        }
    }
    
    // MARK: - Fetch Scores from API
    func fetchScores() {
        isLoading = true
        errorMessage = nil
        
        var parameters: [String: String] = [:]
        
        // If passed explicit ID (like "PAT001"), use it.
        // If passed numeric ID as string (like "1"), AND email is available, prefer email
        // because numeric ID won't match "PATxxx" in DB column.
        
        if let email = patientEmail, !email.isEmpty {
             parameters["email"] = email
        } else {
             parameters["patient_id"] = patientId
        }
        
        NetworkManager.shared.postRequest(endpoint: "getScoresById.php", parameters: parameters, responseType: ScoreListResponse.self) { result in
             DispatchQueue.main.async {
                 self.isLoading = false
                 switch result {
                 case .success(let response):
                     if response.success, let fetchedScores = response.scores {
                         self.scores = fetchedScores
                     } else {
                         self.scores = [] // Empty but success or handled failure
                         if !response.success {
                             // Optional: show "No scores" instead of error if success=false but just means empty
                             // But checking PHP: if count==0, success=false, message="No scores found"
                             // So we treat success=false as empty list if desired, or show message.
                             // self.errorMessage = "No scores found"
                         }
                     }
                 case .failure(let error):
                     self.errorMessage = "Error: \(error.localizedDescription)"
                 }
             }
        }
    }
}


// MARK: - Remove old ScoreEntry model (no longer needed)

#Preview {
    ScoreDetails(patientId: "PAT001")
}
