//
//  Available Slots.swift
//  Renal Guard
//
//  Created by SAIL L1 on 03/01/26.
//
import SwiftUI

struct AvailableSlots: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = AppointmentViewModel()
    @AppStorage("user_id") private var userId: Int = 0
    @AppStorage("email") private var patientEmail: String = "" // Added email
    
    let doctorId: String
    let scheduleId: Int
    let scheduleDate: String
    
    @State private var showSuccessAlert = false
    @State private var alertTitle: String = ""
    @State private var alertMessage: String = ""
    @State private var navigateToDashboard = false
    
    var body: some View {
        ZStack {
            // ... (rest of body remains same until bookSlot call)
            Color.white.ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Custom Top Bar
                ZStack(alignment: .center) {
                    Color(red: 0/255, green: 128/255, blue: 128/255)
                    
                    HStack {
                        Button(action: { dismiss() }) {
                            HStack(spacing: 4) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.white)
                                    .padding(.top, 40)
                                
                                Text("Back")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.white)
                                    .padding(.top, 40)
                            }
                        }
                        .padding(.leading, 16)
                        
                        Spacer()
                    }
                    
                    Text("Available Slots")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 40)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 100)
                .ignoresSafeArea(edges: .top)
                .padding(.top, -20)
                
                // Content
                if viewModel.isLoading {
                    Spacer()
                    ProgressView()
                        .scaleEffect(1.5)
                    Spacer()
                } else if let errorMessage = viewModel.errorMessage {
                    Spacer()
                    VStack(spacing: 16) {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.system(size: 50))
                            .foregroundColor(.red)
                        Text(errorMessage)
                            .multilineTextAlignment(.center)
                            .padding()
                        Button("Retry") {
                            Task {
                                await loadSlots()
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(Color(red: 0/255, green: 128/255, blue: 128/255))
                    }
                    Spacer()
                } else if viewModel.availableSlots.isEmpty || viewModel.availableSlots.allSatisfy({ $0.availableSlots.isEmpty }) {
                    Spacer()
                    VStack(spacing: 16) {
                        Image(systemName: "calendar.badge.clock")
                            .font(.system(size: 50))
                            .foregroundColor(.gray)
                        Text("All slots are booked")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.gray)
                        Text("Please check back later")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                    Spacer()
                } else {
                    // Info Message
                    HStack(spacing: 8) {
                        Image(systemName: "info.circle.fill")
                            .foregroundColor(Color(red: 0/255, green: 128/255, blue: 128/255))
                        Text("You can book multiple slots per day")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                    .background(Color(red: 240/255, green: 248/255, blue: 248/255))
                    .cornerRadius(8)
                    .padding(.horizontal)
                    .padding(.top, 8)
                    ScrollView {
                        VStack(spacing: 16) {
                            ForEach(viewModel.availableSlots) { schedule in
                                ForEach(schedule.availableSlots) { slot in
                                    SlotCard(slot: slot) {
                                        Task {
                                            await bookSlot(slot: slot)
                                        }
                                    }
                                }
                            }
                        }
                        .padding()
                    }
                }
            }
            
            // Custom Success Full Screen
            if showSuccessAlert {
                ZStack {
                    Color.white
                        .ignoresSafeArea()
                    
                    VStack(spacing: 30) {
                        Spacer()
                        
                        Text("Your appointment has been\nbooked successfully!")
                            .font(.system(size: 22, weight: .semibold))
                            .foregroundColor(.black)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        Button(action: {
                            showSuccessAlert = false
                            navigateToDashboard = true
                        }) {
                            Text("Done")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 140, height: 50)
                                .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                                .cornerRadius(25)
                        }
                        
                        Spacer()
                    }
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .navigationDestination(isPresented: $navigateToDashboard) {
            PatientDashboard(patientId: userId)
                .navigationBarBackButtonHidden(true)
        }
        .task {
            await loadSlots()
        }
    }
    
    private func loadSlots() async {
        await viewModel.fetchAvailableSlots(doctorId: doctorId, scheduleId: scheduleId, date: scheduleDate)
    }
    
    private func bookSlot(slot: TimeSlot) async {
        await viewModel.bookAppointment(
            patientId: userId,
            slotId: slot.id,
            scheduleId: scheduleId,
            patientEmail: patientEmail,
            slotTime: slot.slotStartTime,
            doctorId: doctorId,
            appointmentDate: scheduleDate
        )
        
        if viewModel.showSuccess {
            // Format time to 12-hour format for display
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm"
            alertTitle = "Booking Successful"
            alertMessage = "Your appointment has been booked successfully!"
            showSuccessAlert = true
        }
    }
}

// MARK: - Slot Card
struct SlotCard: View {
    let slot: TimeSlot
    let onBook: () -> Void
    
    var body: some View {
        HStack {
            Text(formatTime12Hour(slot.slotStartTime))
                .font(.system(size: 18, weight: .medium))
                .padding(.leading, 20)
            
            Spacer()
            
            Button(action: onBook) {
                Text("Book")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(width: 90, height: 40)
                    .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                    .cornerRadius(20)
            }
            .padding(.trailing, 20)
        }
        .frame(height: 70)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.black, lineWidth: 1.5)
        )
    }
    
    private func formatTime12Hour(_ timeString: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        guard let time = formatter.date(from: String(timeString.prefix(5))) else { return timeString }
        
        formatter.dateFormat = "hh:mm a"
        return formatter.string(from: time)
    }
}

#Preview {
    AvailableSlots(doctorId: "DOC03", scheduleId: 1, scheduleDate: "2026-01-10")
}

