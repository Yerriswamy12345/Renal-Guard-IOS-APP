import SwiftUI

struct PatientProfile: View {
    @Environment(\.dismiss) private var dismiss

    @AppStorage("name") var isname: String = ""
    @AppStorage("email") var myemail: String = ""
    @AppStorage("phone") var mymobile: String = ""
    @AppStorage("user_id") var storedUserId: Int = 0

    @State private var changePassword = ""
    @State private var reEnterPassword = ""

    @State private var goToAboutUs = false
    @State private var goToLogin = false

    @State private var showAlert = false
    @State private var alertMessage = ""

    @FocusState private var focusedField: Field?

    enum Field {
        case name, mobile, password, reEnterPassword
    }

    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()

            VStack(spacing: 0) {

                // TOP BAR
                VStack {
                    HStack {
                        Button(action: { goToAboutUs = true }) {
                            Image(systemName: "info.circle")
                                .font(.system(size: 26))
                                .foregroundColor(.white)
                        }

                        Spacer()

                        Text("Profile")
                            .font(.system(size: 26, weight: .bold))
                            .foregroundColor(.white)

                        Spacer()

                        Button(action: { goToLogin = true }) {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .font(.system(size: 22))
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 14)
                    .padding(.top, -20)
                }
                .background(Color(red: 0/255, green: 128/255, blue: 128/255))

                // CONTENT
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 15) {
                        VStack(spacing: 15) {

                            Image("Image 3")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)

                            Group {
                                profileField(title: "Name", text: $isname)
                                    .focused($focusedField, equals: .name)

                                profileField(title: "Mobile Number", text: $mymobile)
                                    .focused($focusedField, equals: .mobile)

                                profileField(title: "E-Mail Address", text: $myemail)
                                    .disabled(true)
                                    .opacity(0.6)

                                profileField(title: "Change Password",
                                             text: $changePassword,
                                             isSecure: true)
                                    .focused($focusedField, equals: .password)

                                Text("Password must be at least 8 characters, include 1 number and 1 special character")
                                    .font(.system(size: 13))
                                    .foregroundColor(.gray)

                                profileField(title: "Re-Enter Password",
                                             text: $reEnterPassword,
                                             isSecure: true)
                                    .focused($focusedField, equals: .reEnterPassword)
                            }
                        }
                        .padding()
                        .background(Color(red: 230/255, green: 242/255, blue: 242/255))
                        .cornerRadius(16)
                        .shadow(radius: 4)
                        .padding(.top, 20)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 120)
                    }
                }

                // SAVE BUTTON
                VStack {
                    Button(action: updatePatientPassword) {
                        Text("Save & Exit")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                            .cornerRadius(12)
                            .padding(.horizontal, 40)
                    }
                    .padding(.bottom, 20)
                }
            }
        }
        // ✅ SWIPE BACK (LEFT → RIGHT)
        .gesture(
            DragGesture()
                .onEnded { value in
                    if value.translation.width > 100 {
                        dismiss()
                    }
                }
        )

        .navigationBarBackButtonHidden(true)
        .navigationDestination(isPresented: $goToAboutUs) { AboutUs() }
        .navigationDestination(isPresented: $goToLogin) { LoginView() }
        .onAppear { loadUserProfile() }

        .alert("Password Update", isPresented: $showAlert) {
            Button("OK") {
                if alertMessage.lowercased().contains("success") {
                    goToLogin = true
                }
            }
        } message: {
            Text(alertMessage)
        }
    }

    // UPDATE PROFILE
    func updatePatientPassword() {
        focusedField = nil

        if !changePassword.isEmpty {
            if changePassword != reEnterPassword {
                alertMessage = "Passwords do not match"
                showAlert = true
                return
            }

            let passwordPattern = "^(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$"
            if !NSPredicate(format: "SELF MATCHES %@", passwordPattern)
                .evaluate(with: changePassword) {
                alertMessage = "Password must meet complexity rules"
                showAlert = true
                return
            }
        }

        let parameters: [String: Any?] = [
            "email": myemail,
            "name": isname,
            "phone": mymobile,
            "password": changePassword.isEmpty ? nil : changePassword
        ]

        NetworkManager.shared.postRequest(
            endpoint: "updatepatientprofile.php",
            parameters: parameters.compactMapValues { $0 },
            responseType: PatientUpdateResponse.self
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    alertMessage = response.message
                case .failure(let error):
                    alertMessage = error.localizedDescription
                }
                showAlert = true
            }
        }
    }

    // LOAD PROFILE
    func loadUserProfile() {
        guard !myemail.isEmpty else { return }

        NetworkManager.shared.postRequest(
            endpoint: "getpatientprofile.php",
            parameters: ["email": myemail],
            responseType: UserResponse.self
        ) { result in
            DispatchQueue.main.async {
                if case let .success(response) = result, response.success {
                    isname = response.data.name
                    mymobile = response.data.phone
                }
            }
        }
    }

    // FIELD UI
    func profileField(title: String, text: Binding<String>, isSecure: Bool = false) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 16))

            if isSecure {
                SecureField(title, text: text)
                    .padding(10)
                    .background(Color.white)
                    .cornerRadius(6)
            } else {
                TextField(title, text: text)
                    .padding(10)
                    .background(Color.white)
                    .cornerRadius(6)
            }
        }
    }
}

// MARK: - MODELS
struct UserResponse: Codable {
    let success: Bool
    let data: User
}

struct User: Codable {
    let name: String
    let email: String
    let phone: String
}

struct PatientUpdateResponse: Codable {
    let success: Bool
    let message: String
}

#Preview {
    PatientProfile()
}
