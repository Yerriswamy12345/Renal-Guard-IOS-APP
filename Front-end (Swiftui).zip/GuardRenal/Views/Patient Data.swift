import SwiftUI

struct PatientData: View {
    
    // ✅ Accept patient data from Doctor Dashboard
    let patient: DoctorPatientModel
    
    @Environment(\.dismiss) private var dismiss

    // Navigation triggers
    @State private var goToPatientDetails = false
    @State private var goToAssessment = false
    @State private var goToScoreDetails = false
    
    var body: some View {
        ZStack {
            // ✅ Background
            Color.white
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                
                // ✅ Custom Top Bar
                ZStack(alignment: .center) {
                    Color(red: 0/255, green: 128/255, blue: 128/255)
                    
                    HStack {
                        // 🔙 Custom Back Button → DoctorDashboard
                        Button(action: {
                            dismiss()
                        }) {
                            HStack(spacing: 4) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.white)
                                    .padding(.top, 40)
                                
                                Text("Back")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.white)
                                    .padding(.top, 40)
                            }
                        }
                        .padding(.leading, 16)
                        
                        Spacer()
                    }
                    
                    // 🩺 Title
                    Text("Patient Data")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 40)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 100)
                .ignoresSafeArea(edges: .top)
                
                // ✅ Patient Info Card
                HStack(spacing: 12) {
                    Image(systemName: "person.fill")
                        .font(.system(size: 45))
                        .foregroundColor(Color(red: 0/255, green: 128/255, blue: 128/255))
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text("\(patient.displayName) (ID: \(patient.patient_id))")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.black)
                        Text(patient.displayEmail)
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    Spacer()
                }
                .padding()
                .background(Color.white)
                .cornerRadius(15)
                .shadow(radius: 1)
                .padding(.horizontal, 20)
                
                // ✅ Navigation Buttons Section
                VStack(spacing: 20) {
                    
                    Button(action: {
                        goToPatientDetails = true
                    }) {
                        patientButtonLabel(title: "Patient Details")
                    }
                    
                    Button(action: {
                        goToScoreDetails = true
                    }) {
                        patientButtonLabel(title: "Score Results")
                    }
                    
                    Button(action: {
                        goToAssessment = true
                    }) {
                        patientButtonLabel(title: "Assessment")
                    }
                }
                .padding(.top, 10)
                
                Spacer()
                
                // ✅ Bottom Back Button → DoctorDashboard
                Button(action: {
                     dismiss()
                }) {
                    Text("Back")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                        .cornerRadius(30)
                        .padding(.horizontal, 40)
                }
                .padding(.bottom, 20)
            }
        }
        // 🚫 Hide system navigation bar & back button
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        
        // ✅ Navigation Destinations
        .navigationDestination(isPresented: $goToPatientDetails) {
            PatientDetails(patient: patient)
        }
        .navigationDestination(isPresented: $goToAssessment) {
            Assessment(patientId: patient.patientNo, patientEmail: patient.email ?? "")
        }
        .navigationDestination(isPresented: $goToScoreDetails) {
            ScoreDetails(patientId: patient.patientNo)
        }
    }
    
    // MARK: - Reusable Button Label
    private func patientButtonLabel(title: String) -> some View {
        Text(title)
            .font(.system(size: 18, weight: .semibold))
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 50)
            .background(Color(red: 0/255, green: 128/255, blue: 128/255))
            .cornerRadius(25)
            .padding(.horizontal, 40)
    }
}

#Preview {
    PatientData(patient: DoctorPatientModel(
        patient_id: "P001",
        user_id: 10,
        name: "Meena",
        email: "meena20@gmail.com",
        phone: "1234567890",
        age: 20,
        gender: "Female",
        latest_score: 11,
        latest_date: "2025-10-28 10:30:00"
    ))
}
