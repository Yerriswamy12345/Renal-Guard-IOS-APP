//
//  MyAppointments.swift
//  Renal Guard
//
//  Created by Sail L1 on 10/11/25.
//
//  Updated by Assistant to use Real Data
//

import SwiftUI

struct MyAppointments: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = PatientAppointmentsViewModel()
    @AppStorage("email") private var patientEmail: String = ""

    var body: some View {
        NavigationStack {
            ZStack {
                // ✅ Background
                Color.white
                    .ignoresSafeArea()

                VStack(spacing: 20) {

                    // ✅ Custom Top Bar
                    ZStack(alignment: .center) {
                        Color(red: 0/255, green: 128/255, blue: 128/255)

                        HStack {
                            // 🔙 Custom Back Button
                            Button(action: { dismiss() }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "chevron.left")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)

                                    Text("Back")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)
                                }
                            }
                            .padding(.leading, 16)

                            Spacer()
                        }

                        // 🩺 Title
                        Text("My Appointments")
                            .font(.system(size: 26, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.top, 40)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 100)
                    .ignoresSafeArea(edges: .top)
                    .padding(.top, -20)

                    // ✅ Appointment Cards
                    if viewModel.isLoading {
                        ProgressView("Loading appointments...")
                            .padding(.top, 50)
                    } else if let error = viewModel.errorMessage {
                        VStack {
                            Text("Error loading appointments")
                            Text(error).font(.caption).foregroundColor(.red)
                            Button("Retry") {
                                viewModel.fetchAppointments(patientEmail: patientEmail)
                            }
                        }
                        .padding(.top, 50)
                    } else if viewModel.appointments.isEmpty {
                        Text("No appointments found.")
                            .padding(.top, 50)
                            .foregroundColor(.gray)
                    } else {
                        ScrollView(showsIndicators: false) {
                            VStack(spacing: 20) {
                                ForEach(viewModel.appointments) { appointment in
                                    AppointmentCard(appointment: appointment) { newStatus in
                                        viewModel.updateAppointmentStatus(
                                            appointmentId: appointment.appointment_id,
                                            status: newStatus,
                                            patientEmail: patientEmail
                                        )
                                    }
                                }
                            }
                            .padding(.horizontal, 10)
                        }
                    }

                    Spacer()
                }
            }
            // ❌ Hide system default navigation bar (no system back button)
            .toolbar(.hidden, for: .navigationBar)
            .onAppear {
                viewModel.fetchAppointments(patientEmail: patientEmail)
            }
        }
    }
}

// MARK: - Appointment Card View
struct AppointmentCard: View {
    var appointment: Appointment
    var onStatusChange: (String) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            // 🕒 Doctor Slot
            Text("Doctor Slot: \(appointment.slot)")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
                .padding(.top, 8)

            // 📅 Date and Slot
            Text("Date: \(appointment.date) | Slot: \(appointment.slotTime)")
                .font(.system(size: 15))
                .foregroundColor(.black)

            // 🩺 Status
            Text("Status: \(appointment.status)")
                .italic()
                .font(.system(size: 15))
                .foregroundColor(.gray)
                .padding(.bottom, 5)

            // ✅ Buttons Row
            HStack(spacing: 12) {
                // Attended Button
                Button(action: {
                    onStatusChange("attended")
                }) {
                    Text("Attended")
                        .font(.system(size: 15, weight: .semibold))
                        // Text white if active (Teal), black if disabled (Gray)
                        .foregroundColor(isActive ? .white : .black)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 8)
                        .background(isActive ? Color(red: 0/255, green: 128/255, blue: 128/255) : Color.gray.opacity(0.2))
                        .cornerRadius(20)
                }
                .disabled(!isActive)

                // Missed Button
                Button(action: {
                    onStatusChange("missed")
                }) {
                    Text("Missed")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(isActive ? .white : .black)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 8)
                        .background(isActive ? Color(red: 0/255, green: 128/255, blue: 128/255) : Color.gray.opacity(0.2))
                        .cornerRadius(20)
                }
                .disabled(!isActive)

                Spacer()

                // Cancel Button
                Button(action: {
                    onStatusChange("cancelled")
                }) {
                    Text("Cancel")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 25)
                        .padding(.vertical, 8)
                        .background(appointment.status == "cancelled" ? Color.gray : Color.red)
                        .cornerRadius(20)
                }
                .disabled(appointment.status == "cancelled" || appointment.status == "attended" || appointment.status == "missed")
            }
            .padding(.bottom, 8)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 10)
        .background(Color.white)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.black, lineWidth: 1)
        )
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 1)
        .padding(.horizontal, 8)
    }
    
    // Check if appointment is active (pending/booked)
    var isActive: Bool {
        return appointment.status == "booked" || appointment.status == "pending"
    }
}

#Preview {
    MyAppointments()
}
