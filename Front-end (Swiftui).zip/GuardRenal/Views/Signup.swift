import SwiftUI

struct Signup: View {
    @Environment(\.dismiss) private var dismiss
    @State private var goToLogin = false

    @State private var fullName = ""
    @State private var email = ""
    @State private var phone = ""
    @State private var password = ""

    // 👁 Password visibility
    @State private var isPasswordVisible = false

    @AppStorage("fullName") var isname: String = ""
    @AppStorage("email") var myemail: String = ""
    @AppStorage("phone") var mymobile: String = ""

    @FocusState private var focusedField: Field?

    enum Field {
        case name, email, phone
    }

    let userType = "Patient"
    let themeColor = Color(red: 0/255, green: 128/255, blue: 128/255)

    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        NavigationStack {
            ZStack {
                Color.white.ignoresSafeArea()

                VStack(spacing: 20) {

                    // -------- HEADER --------
                    HStack {
                        Button(action: { dismiss() }) {
                            HStack(spacing: 6) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 18, weight: .medium))
                                    .foregroundColor(.white)
                                Text("Back")
                                    .foregroundColor(.white)
                            }
                        }

                        Spacer()

                        Text("Create Account")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.white)

                        Spacer()

                        // Invisible spacer to keep title centered
                        HStack {
                            Image(systemName: "chevron.left").opacity(0)
                            Text("Back").opacity(0)
                        }
                    }
                    .padding(.horizontal)
                    .frame(height: 60)
                    .background(themeColor)
                    .navigationBarBackButtonHidden(true)

                    Text("Join Renal Guard and manage your dialysis care easily")
                        .font(.system(size: 18))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)

                    // -------- INPUTS --------
                    VStack(spacing: 18) {

                        CustomTextField(
                            placeholder: "Full Name",
                            text: $fullName
                        )
                        .focused($focusedField, equals: .name)

                        CustomTextField(
                            placeholder: "Email Address",
                            text: $email
                        )
                        .focused($focusedField, equals: .email)

                        CustomTextField(
                            placeholder: "Phone Number",
                            text: $phone
                        )
                        .focused($focusedField, equals: .phone)

                        // 👁 Password field with eye icon
                        CustomPasswordField(
                            placeholder: "Password",
                            text: $password,
                            isVisible: $isPasswordVisible
                        )

                        Text("At least 8 characters, one number, one special character")
                            .font(.system(size: 14, weight: .semibold))
                            .multilineTextAlignment(.center)

                        HStack {
                            Text(userType)
                                .font(.system(size: 20))
                            Spacer()
                        }
                        .padding(.vertical, 12)
                        .padding(.horizontal, 20)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.black, lineWidth: 1)
                        )
                    }
                    .padding(.horizontal, 20)

                    Spacer()

                    // -------- SIGN UP BUTTON --------
                    Button(action: {
                        focusedField = nil
                        signupUser()
                    }) {
                        Text("Sign Up")
                            .font(.system(size: 22, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(themeColor)
                            .cornerRadius(50)
                            .shadow(color: .gray.opacity(0.4), radius: 3, x: 0, y: 2)
                    }
                    .padding(.horizontal, 30)
                    .padding(.bottom, 25)
                    .alert(isPresented: $showAlert) {
                        Alert(
                            title: Text("Signup"),
                            message: Text(alertMessage),
                            dismissButton: .default(Text("OK"))
                        )
                    }
                }
            }
            .navigationDestination(isPresented: $goToLogin) {
                LoginView()
            }
        }
    }

    // MARK: - API CALL
    func signupUser() {
        guard !fullName.isEmpty,
              !email.isEmpty,
              !phone.isEmpty,
              !password.isEmpty else {
            alertMessage = "Please fill in all fields"
            showAlert = true
            return
        }

        let parameters: [String: Any] = [
            "name": fullName,
            "email": email,
            "phone": phone,
            "password": password,
            "role": userType
        ]

        NetworkManager.shared.postRequest(
            endpoint: "register.php",
            parameters: parameters,
            responseType: SignupResponse.self
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.success {
                        alertMessage = "Registration Successful"
                        showAlert = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            isname = fullName
                            myemail = email
                            mymobile = phone
                            goToLogin = true
                        }
                    } else {
                        alertMessage = response.message
                        showAlert = true
                    }
                case .failure(let error):
                    alertMessage = error.localizedDescription
                    showAlert = true
                }
            }
        }
    }
}

#Preview {
    Signup()
}

//
// MARK: - SUPPORTING VIEWS & MODELS (SAME FILE)
//

// Text Field
struct CustomTextField: View {
    var placeholder: String
    @Binding var text: String

    var body: some View {
        TextField(placeholder, text: $text)
            .padding()
            .font(.system(size: 20))
            .textInputAutocapitalization(.never)
            .disableAutocorrection(true)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black, lineWidth: 1)
            )
    }
}

// Password Field with Eye 👁
struct CustomPasswordField: View {
    var placeholder: String
    @Binding var text: String
    @Binding var isVisible: Bool

    var body: some View {
        HStack {
            Group {
                if isVisible {
                    TextField(placeholder, text: $text)
                } else {
                    SecureField(placeholder, text: $text)
                }
            }
            .font(.system(size: 20))
            .textInputAutocapitalization(.never)
            .disableAutocorrection(true)

            Button {
                isVisible.toggle()
            } label: {
                Image(systemName: isVisible ? "eye.slash.fill" : "eye.fill")
                    .foregroundColor(.black.opacity(0.7))
            }
        }
        .padding()
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.black, lineWidth: 1)
        )
    }
}

// MARK: - API Models
struct SignupResponse: Codable {
    let success: Bool
    let message: String
    let data: SignupData?
}

struct SignupData: Codable {
    let user: SignupUser?
}

struct SignupUser: Codable {
    let id: Int
    let name: String
    let email: String
    let phone: String
    let role: String
}
