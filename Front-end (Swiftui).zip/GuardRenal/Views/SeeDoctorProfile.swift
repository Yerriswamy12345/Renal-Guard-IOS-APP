//
//  SeeDoctorprofile.swift
//  Renal Guard
//
//  Created by Sail L1 on 10/11/25.
//

import SwiftUI

struct SeeDoctorprofile: View {
    @Environment(\.dismiss) private var dismiss
    
    // ✅ Accept patient ID to pass back
    let patientId: Int
    
    @State private var goToHomepage = false

    var body: some View {
        NavigationStack {
            ZStack {
                // ✅ Background color
                Color.white
                    .ignoresSafeArea()

                VStack(spacing: 25) {

                    // ✅ Custom Top Bar
                    ZStack(alignment: .center) {
                        Color(red: 0/255, green: 128/255, blue: 128/255)

                        HStack {
                            // 🔙 Custom Back Button (with text)
                            Button(action: { dismiss() }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "chevron.left")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)
                                    
                                    Text("Back")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)
                                }
                            }
                            .padding(.leading, 16)

                            Spacer()
                        }

                        // 🩺 Title
                        Text("Doctor Details")
                            .font(.system(size: 26, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.top, 40)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 100)
                    .ignoresSafeArea(edges: .top)
                    .padding(.top, -20)

                    // ✅ Doctor Info Card (same width as below box)
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(spacing: 12) {
                            Image("Image 5")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 60, height: 60)
                                .padding(.leading, 10)

                            VStack(alignment: .leading, spacing: 4) {
                                Text("Pavithra V")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.black)

                                Text("Nephrologist")
                                    .font(.system(size: 16))
                                    .foregroundColor(.gray)

                                Text("Hyderabad, Telegana")
                                    .font(.system(size: 16))
                                    .foregroundColor(.gray)
                            }

                            Spacer()
                        }
                        .padding(.vertical, 10)
                    }
                    .padding(10)
                    .frame(maxWidth: .infinity) // ✅ full horizontal width same as next box
                    .background(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 1)
                    )
                    .padding(.horizontal, 20)

                    // ✅ About The Doctor Section (same width as top box)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("About The Doctor")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.black)

                        Text("Doctor Email: pavithravalleti06@gmail.com")
                            .font(.system(size: 16))
                            .foregroundColor(.black)

                        Text("Phone: 7386739779")
                            .font(.system(size: 16))
                            .foregroundColor(.black)

                        Text("Education: MBBS, FRCS")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    .padding(10)
                    .frame(maxWidth: .infinity) // ✅ same width as top box
                    .background(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.black, lineWidth: 1)
                    )
                    .padding(.horizontal, 20)

                    Spacer()

                    // ✅ Back to Homepage Button
                    Button(action: {
                        goToHomepage = true
                    }) {
                        Text("Back To Homepage")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.black)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color(red: 0/255, green: 128/255, blue: 128/255), lineWidth: 2)
                            )
                            .padding(.horizontal, 50)
                    }
                    .padding(.bottom, 10)
                }
            }
            // ✅ Hide system default navigation bar
            .toolbar(.hidden, for: .navigationBar)

            // ✅ Navigation back to homepage
            .navigationDestination(isPresented: $goToHomepage) {
                PatientDashboard(patientId: patientId)
                    .navigationBarBackButtonHidden(true)
            }
        }
    }
}

#Preview {
    SeeDoctorprofile(patientId: 1)
}
