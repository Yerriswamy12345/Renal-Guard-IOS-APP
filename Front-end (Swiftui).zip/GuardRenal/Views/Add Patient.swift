import SwiftUI

struct AddPatient: View {

    // MARK: - Navigation
    @State private var goToAssessment = false
    @State private var goBack = false

    // MARK: - Patient Inputs
    @State private var name = ""
    @State private var age = ""
    @State private var gender = "Select Gender"
    @State private var email = ""
    @State private var mobile = ""

    // MARK: - UI State
    @State private var showGenderPicker = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    @FocusState private var focusedField: Field?
    
    enum Field {
        case name, age, email, mobile
    }

    // MARK: - API Response
    @State private var createdPatientId: String?

    // ✅ Doctor ID & Email
    @AppStorage("user_id") private var doctorUserId: Int = 0
    @AppStorage("email") private var doctorEmail: String = ""

    var body: some View {
        NavigationStack {
            ZStack {
                Color.white.ignoresSafeArea()

                VStack(spacing: 0) {

                    // MARK: - TOP BAR
                    ZStack {
                        Color(red: 0/255, green: 128/255, blue: 128/255)

                        HStack {
                            Button {
                                goBack = true
                            } label: {
                                HStack {
                                    Image(systemName: "chevron.left")
                                    Text("Back")
                                }
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                            }
                            .padding(.leading, 16)
                            .padding(.top, 40)

                            Spacer()
                        }

                        Text("Add Patient")
                            .font(.system(size: 26, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.top, 40)
                    }
                    .frame(height: 100)
                    .ignoresSafeArea(edges: .top)

                    // MARK: - FORM
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 20) {

                            VStack(alignment: .leading, spacing: 15) {

                                Text("Patient Details")
                                    .font(.system(size: 22, weight: .heavy))

                                customField("Name", text: $name)
                                    .focused($focusedField, equals: .name)

                                customField("Age", text: $age)
                                    .focused($focusedField, equals: .age)
                                    .keyboardType(.numberPad)

                                // MARK: - Gender Picker
                                Button {
                                    showGenderPicker.toggle()
                                } label: {
                                    HStack {
                                        Text(gender)
                                            .foregroundColor(
                                                gender == "Select Gender" ? .gray : .black
                                            )
                                        Spacer()
                                        Image(systemName: "chevron.down")
                                    }
                                    .padding()
                                    .background(Color(red: 224/255, green: 245/255, blue: 245/255))
                                    .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.black))
                                }
                                .confirmationDialog("Select Gender", isPresented: $showGenderPicker) {
                                    Button("Male") { gender = "Male" }
                                    Button("Female") { gender = "Female" }
                                    Button("Others") { gender = "Others" }
                                    Button("Cancel", role: .cancel) {}
                                }

                                // MARK: - Email
                                TextField("Email", text: $email)
                                    .padding()
                                    .background(Color(red: 224/255, green: 245/255, blue: 245/255))
                                    .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.black))
                                    .focused($focusedField, equals: .email)
                                    .keyboardType(.emailAddress)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled(true)
                                    .onChange(of: email) {
                                        email = email.lowercased()
                                    }

                                customField("Mobile Number", text: $mobile)
                                    .focused($focusedField, equals: .mobile)
                                    .keyboardType(.numberPad)

                                // MARK: - NEXT BUTTON
                                Button {
                                    addPatientToServer()
                                } label: {
                                    Text("Next")
                                        .font(.system(size: 20, weight: .semibold))
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 12)
                                        .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                                        .cornerRadius(10)
                                }
                                .padding(.top, 10)
                            }
                            .padding(20)
                            .background(Color(red: 224/255, green: 245/255, blue: 245/255))
                            .overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.black))
                            .cornerRadius(15)
                            .padding(.horizontal, 20)
                            .padding(.top, 20)
                        }
                        .padding(.bottom, 40)
                    }
                }
            }
            .toolbar(.hidden, for: .navigationBar)

            // MARK: - ALERT
            .alert("Add Patient", isPresented: $showAlert) {
                Button("OK") {
                    if alertMessage.contains("successfully") {
                        goToAssessment = true
                    }
                }
            } message: {
                Text(alertMessage)
            }

            // MARK: - NAVIGATION
            .navigationDestination(isPresented: $goBack) {
                DoctorDashboard()
            }

            .navigationDestination(isPresented: $goToAssessment) {
                if let patientId = createdPatientId {
                    Assessment(
                        patientId: patientId,
                        patientEmail: email
                    )
                }
            }
        }
    }

    // MARK: - API CALL FUNCTION
    private func addPatientToServer() {
        focusedField = nil // Dismiss keyboard
        
        guard !name.isEmpty, !age.isEmpty, !email.isEmpty, !mobile.isEmpty, gender != "Select Gender" else {
            alertMessage = "Please fill in all fields"
            showAlert = true
            return
        }
        
        guard let ageInt = Int(age) else {
            alertMessage = "Invalid Age"
            showAlert = true
            return
        }
        
        let parameters: [String: Any] = [
            "name": name,
            "age": ageInt,
            "email": email,
            "phone": mobile,
            "doctor_email": doctorEmail,
            "gender": gender
        ]
        
        NetworkManager.shared.postRequest(endpoint: "add_patient.php", parameters: parameters, responseType: AddPatientResponse.self) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.success {
                        // Use patient_id from response (e.g., "PAT001")
                        createdPatientId = response.patient_id
                        
                        alertMessage = "Patient added successfully"
                        showAlert = true
                    } else {
                        alertMessage = response.message
                        showAlert = true
                    }
                case .failure(let error):
                    alertMessage = "Error: \(error.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }

    // MARK: - Custom Field
    private func customField(_ placeholder: String, text: Binding<String>) -> some View {
        TextField(placeholder, text: text)
            .padding()
            .background(Color(red: 224/255, green: 245/255, blue: 245/255))
            .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.black))
            .font(.system(size: 16))
    }
}

// MARK: - API Response
struct AddPatientResponse: Codable {
    let success: Bool
    let message: String
    let patient_id: String?
}

#Preview {
    AddPatient()
}
