import SwiftUI

struct AboutDieting: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            Color(red: 250/255, green: 240/255, blue: 246/255)
                .ignoresSafeArea()

            VStack(spacing: 0) {

                // ✅ Top Bar (adaptive for all devices)
                ZStack {
                    Color(red: 0/255, green: 128/255, blue: 128/255)

                    HStack {
                        Button(action: { dismiss() }) {
                            HStack(spacing: 4) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.white)

                                Text("Back")
                                    .font(.system(size: 18, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                        }
                        .padding(.leading, 16)
                        .padding(.top, 40)

                        Spacer()
                    }

                    Text("About Dieting")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 40)
                }
                .frame(height: 100)
                .ignoresSafeArea(edges: .bottom)
                .padding(.top,-65)

                // ⭐ Content automatically adjusts to all devices
                ScrollView {
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Dietary Plans Which Can Be Followed By Dialysis Patients:")
                            .font(.system(size: 20, weight: .medium))
                            .foregroundColor(.black)
                            .padding(.bottom, 5)

                        Group {
                            Text("• Limit potassium & phosphorus (avoid bananas, oranges, dairy).")
                            Text("• Increase protein intake (especially in CKD patients on dialysis).")
                            Text("• Fluid management guidelines.")
                            Text("• Sodium restriction for hypertensive patients.")
                        }
                        .font(.system(size: 19))
                        .foregroundColor(.black)
                        .lineSpacing(6)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                }

                Spacer()
            }
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    AboutDieting()
}
