import SwiftUI

struct AboutUs: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {

            // ✅ TOP BAR (same as AdminDashboard)
            ZStack(alignment: .center) {
                Color(red: 0/255, green: 128/255, blue: 128/255)
                    .ignoresSafeArea(edges: .top)

                HStack {
                    Button(action: {
                        dismiss()   // ✅ Go Back
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.white)
                                .padding(.top, 40)

                            Text("Back")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                                .padding(.top, 40)
                        }
                    }
                    .padding(.leading, 16)

                    Spacer()
                }

                // ✅ Centered Title
                Text("About Us")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 40)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 95)
            .ignoresSafeArea(edges: .top)
            .padding(.top,-40)

            // ✅ CONTENT SCROLL (starts just below title with minimal gap)
            ScrollView(showsIndicators: true) {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Renal Guard App: IJV Line Risk and Health for Dialysis")
                        .font(.headline)
                        .fontWeight(.bold)

                    Group {
                        Text("Overview:")
                            .fontWeight(.bold)

                        Text("""
The Renal Guard App is a clinical decision-support tool specifically designed to help healthcare professionals evaluate and manage the risks associated with internal jugular vein (IJV) catheter use in patients undergoing hemodialysis.
IJV lines, while essential for short- or medium-term vascular access, carry inherent risks such as infection, thrombosis, and catheter dysfunction.
This app integrates patient-specific parameters into a comprehensive scoring system (maximum 25 points) to guide evidence-based interventions.
""")

                        Text("Key Features and Functions:")
                            .fontWeight(.bold)
                            .padding(.top, 4) // 🔽 Reduced top padding slightly

                        Text("1. Risk Scoring for IJV Catheters")
                            .fontWeight(.bold)
                        Text("• Calculates total IJV risk score and classifies as low / moderate / high.")

                        Text("2. Sepsis Risk Assessment")
                            .fontWeight(.bold)
                        Text("• Determines sepsis severity and suggests clinical action.")

                        Text("3. Line Management & Infection Prevention")
                            .fontWeight(.bold)
                        Text("• Suggests best practices for catheter replacement and hygiene.")

                        Text("4. Antibiotic Decision Support")
                            .fontWeight(.bold)
                        Text("• Helps choose empirical or targeted antibiotics.")

                        Text("5. Vascular Access Planning")
                            .fontWeight(.bold)
                        Text("• Guides transition to AV fistula for long-term dialysis patients.")

                        Text("6. Dietary Guidance")
                            .fontWeight(.bold)
                        Text("• Suggests nutritional recommendations.")

                        Text("7. Appointment Scheduling & Follow-up")
                            .fontWeight(.bold)
                        Text("• Allows patients to manage and track dialysis appointments.")
                    }

                    Text("Benefits:")
                        .fontWeight(.bold)
                        .padding(.top, 4)

                    Text("""
• Streamlined Clinical Workflow  
• Improved Patient Safety  
• Optimized Long-Term Care
""")
                }
                .padding(.horizontal, 15)
                .padding(.top, -4)  // ✅ Reduced further for tighter layout
                .padding(.bottom, 10)
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}

#Preview {
    NavigationStack {
        AboutUs()
    }
}
