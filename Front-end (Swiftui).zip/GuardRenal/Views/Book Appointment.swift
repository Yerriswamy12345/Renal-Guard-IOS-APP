import SwiftUI

struct BookAppointments: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = AppointmentViewModel()
    @AppStorage("user_email") private var userEmail: String = ""
    
    let doctorId: String   // DOC03
    
    @State private var selectedDate = Date()
    @State private var navigateToSlots = false
    @State private var selectedSchedule: DaySchedule?
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.white.ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Custom Top Bar
                    ZStack(alignment: .center) {
                        Color(red: 0/255, green: 128/255, blue: 128/255)
                        
                        HStack {
                            Button(action: { dismiss() }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "chevron.left")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)
                                    
                                    Text("Back")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)
                                }
                            }
                            .padding(.leading, 16)
                            
                            Spacer()
                        }
                        
                        Text("Book Appointment")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.top, 40)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 100)
                    .ignoresSafeArea(edges: .top)
                    .padding(.top, -20)
                    
                    // Content
                    if viewModel.isLoading {
                        Spacer()
                        ProgressView()
                            .scaleEffect(1.5)
                        Spacer()
                    } else if let errorMessage = viewModel.errorMessage {
                        Spacer()
                        VStack(spacing: 16) {
                            Image(systemName: "exclamationmark.triangle")
                                .font(.system(size: 50))
                                .foregroundColor(.red)
                            Text(errorMessage)
                                .multilineTextAlignment(.center)
                                .padding()
                            Button("Retry") {
                                Task {
                                    await loadSchedules()
                                }
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(Color(red: 0/255, green: 128/255, blue: 128/255))
                        }
                        Spacer()
                    } else if viewModel.daySchedules.filter({ $0.status != "finished" && $0.remainingSlots > 0 }).isEmpty {
                        Spacer()
                        VStack(spacing: 16) {
                            Image(systemName: "calendar.badge.exclamationmark")
                                .font(.system(size: 50))
                                .foregroundColor(.gray)
                            Text("No available schedules at this time")
                                .foregroundColor(.gray)
                        }
                        Spacer()
                    } else {
                        ScrollView {
                            VStack(spacing: 16) {
                                ForEach(viewModel.daySchedules.filter { $0.status != "finished" && $0.remainingSlots > 0 }) { schedule in
                                    ScheduleCard(schedule: schedule) {
                                        selectedSchedule = schedule
                                        navigateToSlots = true
                                    }
                                }
                            }
                            .padding()
                        }
                    }
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(isPresented: $navigateToSlots) {
                if let schedule = selectedSchedule {
                    AvailableSlots(
                        doctorId: doctorId,
                        scheduleId: schedule.scheduleId,
                        scheduleDate: schedule.date
                    )
                    .navigationBarBackButtonHidden(true)
                }
            }
        }
        .task {
            await loadSchedules()
        }
        .onAppear {
            Task {
                await loadSchedules()
            }
        }
    }
    
    private func loadSchedules() async {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: selectedDate)
        
        await viewModel.fetchDaySchedules(doctorId: doctorId, date: dateString)
    }
}

// MARK: - Schedule Card (UNCHANGED UI)
struct ScheduleCard: View {
    let schedule: DaySchedule
    let onBook: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Date: \(formatDate(schedule.date))")
                .font(.system(size: 16, weight: .semibold))
            
            Text("Time: \(formatTime12Hour(schedule.startTime)) - \(formatTime12Hour(schedule.endTime))")
                .font(.system(size: 15))
            
            Text(schedule.status.capitalized)
                .font(.system(size: 15))
                .italic()
                .foregroundColor(statusColor(schedule.status))
            
            Text("Remaining Slots: \(schedule.remainingSlots)")
                .font(.system(size: 15))
            
            Button(action: onBook) {
                Text("Book")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(width: 100, height: 40)
                    .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                    .cornerRadius(20)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(red: 240/255, green: 248/255, blue: 248/255))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
        )
    }
    
    private func formatTime12Hour(_ timeString: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        guard let time = formatter.date(from: timeString) else { return timeString }
        formatter.dateFormat = "hh:mm a"
        return formatter.string(from: time)
    }
    
    private func formatDate(_ dateString: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        guard let date = formatter.date(from: dateString) else { return dateString }
        return formatter.string(from: date)
    }
    
    private func statusColor(_ status: String) -> Color {
        switch status.lowercased() {
        case "ongoing": return .green
        case "finished": return .gray
        default: return .blue
        }
    }
}

#Preview {
    BookAppointments(doctorId: "DOC03")
}
