import SwiftUI

struct PatientDashboard: View {
    // ✅ Patient ID (replace with actual logged-in patient ID)
    let patientId: Int
    
    // Navigation states
    @State private var goToScoreDetails = false
    @State private var goToAboutDiet = false
    @State private var goToPatientProfile = false
    @State private var goToBookAppointment = false
    @State private var goToSeeDoctorProfile = false   // ✅ New for Doctor Profile
    @State private var goToMyAppointments = false     // ✅ New for My Appointments
    
    // ✅ Fetch assigned doctor
    @State private var assignedDoctor: Doctor? = nil
    @AppStorage("email") private var patientEmail: String = ""
    @State private var assignedDoctorError: String? = nil

    var body: some View {
        VStack(spacing: 20) {

            // ✅ Top Teal Header with Centered Title and Right Icon
            ZStack {
                Color(red: 0.0, green: 0.55, blue: 0.55)
                    .ignoresSafeArea(edges: .top)
                    .frame(height: 70)
                    .padding(.top, -15)

                // ✅ Title perfectly centered
                Text("Renal Guard")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.white)
                    .shadow(radius: 2)

                // ✅ Right-side icon (Equal Square)
                HStack {
                    Spacer()
                    Button(action: {
                        goToScoreDetails = true
                    }) {
                        ZStack {
                            Image(systemName: "square.fill")
                                .font(Font.system(size: 26))
                                .foregroundColor(.white)

                            Image(systemName: "equal")
                                .font(Font.system(size: 18, weight: .bold))
                                .foregroundColor(Color(red: 0.0, green: 0.55, blue: 0.55))
                        }
                    }
                    .padding(.trailing, 16)
                }
            }

            // ✅ Search Bar
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                TextField("Search", text: .constant(""))
                    .font(.system(size: 18))
            }
            .padding(.horizontal)
            .frame(height: 45)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.black.opacity(0.6), lineWidth: 1)
            )
            .padding(.horizontal, 20)
            .padding(.top, 5)

            // ✅ Doctor Card (Navigates to Doctor Profile)
            DoctorCardView(doctor: assignedDoctor, action: {
                goToSeeDoctorProfile = true
            })

            // ✅ Book Appointment → Navigation to BookAppointments
            AppointmentCardView(
                icon: "calendar",
                title: "Book Appointment",
                action: {
                    goToBookAppointment = true
                }
            )

            // ✅ View / Update Appointments → Navigation to MyAppointments
            AppointmentCardView(
                icon: "calendar.badge.checkmark",
                title: "View / Update Appointments",
                action: {
                    goToMyAppointments = true
                }
            )

            Spacer()

            // ✅ Rounded Bottom Navigation Bar
            VStack {
               
                HStack(spacing: 100) {
                    // 🏠 Home Icon
                    Image(systemName: "house.fill")
                        .font(Font.system(size: 28))
                        .foregroundColor(.black)

                    // ℹ️ Info Icon → About Diet Page
                    Button(action: {
                        goToAboutDiet = true
                    }) {
                        Image(systemName: "info.circle.fill")
                            .font(Font.system(size: 32))
                            .foregroundColor(.black)
                    }

                    // 👤 Person Icon → Patient Profile Page
                    Button(action: {
                        goToPatientProfile = true
                    }) {
                        Image(systemName: "person.fill")
                            .font(Font.system(size: 28))
                            .foregroundColor(.black)
                    }
                }
                .frame(height: 65)
                .padding(.horizontal, 20)
                .background(Color.white)
                .overlay(
                    RoundedRectangle(cornerRadius: 25)
                        .stroke(Color.black, lineWidth: 2)
                )
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .padding(.horizontal, 10)
                .padding(.bottom, 10)
            }
        }
        .background(Color.white)
        .navigationBarBackButtonHidden(true)
        .navigationBarTitleDisplayMode(.inline)
        .navigationDestination(isPresented: $goToScoreDetails) {
            // ScoreDetails expects String ID (e.g. "PAT001"), but we only have Int here.
            // If patientId (Int) represents the DB ID, we might not have the "PATxxx" ID.
            // However, ScoreDetails uses getScoresById.php which performs query: WHERE patient_id = ?
            // The PHP scripts were inconsistent on what 'patient_id' meant (PK vs string).
            // My update to getScoresById.php uses 'patient_id' column which is varchar usually "PAT...".
            // But AddPatient saves `patient_id` as "PAT..." in column `patient_id`.
            // The `patientId` passed into PatientDashboard comes from LoginView -> storedUserId (Int).
            // LoginUser struct has `id` (Int). 
            // The table `users` has `id`. But `patients` table has `id` AND `patient_id`.
            // We need to fetch the PATIENT string ID using the user ID if we want to query scores by patient_id string.
            // OR, we update getScoresById.php to allow querying by user ID (which is same as `id` in patients table? No `id` in patients table is AI).
            // Wait. `users.id` is not Foreign Key to `patients.id`.
            // LoginView sets `storedUserId = user.id`. This is `users.id`.
            // Does `patients` table have a link to `users` table?
            // `add_doctor.php` inserts into `users` AND `doctors`.
            // `add_patient.php` inserts into `patients` Only. It does NOT insert into `users`?
            // Let's check `add_patient.php`.
            // It DOES NOT insert into `users`.
            // But `Signup.swift` inserts into `users`.
            // So Patients created via `Signup` are in `users`.
            // Patients created via `Add Patient` (by doctor) are in `patients`.
            // These are disjoint sets?
            // If I login as Patient (from `users` table), I have an ID.
            // Is there a corresponding record in `patients` table?
            // The `users` table has no `patient_id` column.
            // This seems to be a schema gap.
            // However, fixing the schema is out of scope.
            // I will just convert the Int to String for now to fix the build, assuming the ID might be usable or just to pass compilation.
            // We pass the email to handle lookup, since patientId might be just the numeric User ID.
            ScoreDetails(patientId: String(patientId), patientEmail: patientEmail)
        }
        .navigationDestination(isPresented: $goToAboutDiet) {
            AboutDieting()
        }
        .navigationDestination(isPresented: $goToPatientProfile) {
            PatientProfile()
        }
       
        .navigationDestination(isPresented: $goToSeeDoctorProfile) {
            DoctorDetails(doctor: assignedDoctor)
        }
        .navigationDestination(isPresented: $goToBookAppointment) {
            if let doctor = assignedDoctor {
                BookAppointments(doctorId: doctor.doctor_id)
            } else if let error = assignedDoctorError {
                VStack {
                    Image(systemName: "exclamationmark.triangle")
                    .font(.largeTitle)
                    .foregroundColor(.orange)
                    Text(error)
                        .multilineTextAlignment(.center)
                        .padding()
                    Button("Retry") {
                        fetchAssignedDoctor()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(Color(red: 0.0, green: 0.55, blue: 0.55))
                }
            } else {
                VStack {
                    ProgressView()
                    Text("Loading doctor information...")
                        .padding(.top)
                }
                .onAppear {
                    fetchAssignedDoctor()
                }
            }
        }
        .navigationDestination(isPresented: $goToMyAppointments) {
            MyAppointments()
        }
        .onAppear {
            fetchAssignedDoctor()
        }
    }
    
    // MARK: - Fetch Assigned Doctor


    // MARK: - Fetch Assigned Doctor
    func fetchAssignedDoctor() {
        guard !patientEmail.isEmpty else { 
            print("DEBUG: Patient email is empty")
            assignedDoctorError = "Patient email not found. Please log in again."
            assignedDoctorError = "Patient email not found in app storage. Please log in again."
            return 
        }
        
        self.assignedDoctorError = nil // Reset error
        
        let parameters = ["email": patientEmail]
        
        print("DEBUG: Fetching doctor for email: \(patientEmail)")
        
        NetworkManager.shared.postRequest(endpoint: "getAssignedDoctor.php", parameters: parameters, responseType: AssignedDoctorResponse.self) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.success, let doctor = response.doctor {
                        print("DEBUG: Doctor fetched successfully: \(doctor.name) (ID: \(doctor.doctor_id))")
                        self.assignedDoctor = doctor
                    } else {
                        print("DEBUG: Failed to fetch doctor: \(response.message ?? "Unknown error")")
                        self.assignedDoctorError = response.message ?? "No doctor assigned to this account."
                    }
                case .failure(let error):
                    print("DEBUG: Network error fetching doctor: \(error.localizedDescription)")
                    self.assignedDoctorError = "Failed to load doctor information: \(error.localizedDescription)"
                }
            }
        }
    }
}


//
// ✅ Doctor Card View (Updated for navigation action and dynamic data)
//
struct DoctorCardView: View {
    var doctor: Doctor?
    var action: (() -> Void)? = nil

    var body: some View {
        HStack {
            Image(systemName: "person.fill")
                .font(Font.system(size: 45))
                .padding(.leading)

            VStack(alignment: .leading, spacing: 5) {
                if let doctor = doctor {
                    Text(doctor.name)
                        .font(.system(size: 18, weight: .bold))
                    Text(doctor.specialization ?? "Specialization not specified")
                        .font(.system(size: 15))
                        .foregroundColor(.gray)
                    Text(doctor.location ?? "Location not specified")
                        .font(.system(size: 15))
                        .foregroundColor(.gray)
                } else {
                    Text("Loading...")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.gray)
                }
            }

            Spacer()

            // ✅ View button triggers navigation
            Button(action: {
                action?()
            }) {
                Text("View")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 30)
                    .padding(.vertical, 10)
                    .background(Color(red: 0.0, green: 0.55, blue: 0.55))
                    .cornerRadius(25)
            }
            .padding(.trailing)
            .disabled(doctor == nil)
            .opacity(doctor == nil ? 0.6 : 1.0)
        }
        .frame(height: 90)
        .background(
            RoundedRectangle(cornerRadius: 15)
                .stroke(Color.black.opacity(0.6), lineWidth: 1)
        )
        .padding(.horizontal, 20)
    }
}


//
// ✅ Appointment Card View (Already supports navigation action)
//
struct AppointmentCardView: View {
    var icon: String
    var title: String
    var action: (() -> Void)? = nil

    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(Font.system(size: 40))
                .padding(.leading)

            Text(title)
                .font(.system(size: 18, weight: .medium))
                .padding(.leading, 8)

            Spacer()

            Button(action: {
                action?()
            }) {
                Text("Go")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 30)
                    .padding(.vertical, 10)
                    .background(Color(red: 0.0, green: 0.55, blue: 0.55))
                    .cornerRadius(25)
            }
            .padding(.trailing)
        }
        .frame(height: 80)
        .background(
            RoundedRectangle(cornerRadius: 15)
                .stroke(Color.black.opacity(0.6), lineWidth: 1)
        )
        .padding(.horizontal, 20)
    }
}

#Preview {
    NavigationStack {
        PatientDashboard(patientId: 1)
    }
}
