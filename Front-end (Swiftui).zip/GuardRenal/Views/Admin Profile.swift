import SwiftUI

struct AdminProfile: View {
    
    @Environment(\.dismiss) private var dismiss
    
    @State private var email: String = ""
    @State private var newPassword: String = ""
    @State private var reEnterPassword: String = ""
    @AppStorage("email") var myemail: String = ""
    @State private var gotoadmindash = false
    @State private var goToLogin = false
    @State private var goToAboutUs = false
    
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    @FocusState private var focusedField: Field?
    
    enum Field {
        case newPassword, reEnterPassword
    }

    var body: some View {
        VStack(spacing: 20) {
            
            // --- CUSTOM TOP BAR ---
            ZStack(alignment: .top) {
                Color(red: 0/255, green: 128/255, blue: 128/255)

                HStack {
                    Button(action: { gotoadmindash = true }) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                        .foregroundColor(.white)
                        .font(.system(size: 20, weight: .medium))
                    }
                    .padding(.top, 55)
                    .padding(.leading, 20)

                    Spacer()

                    Button(action: { goToAboutUs = true }) {
                        Image(systemName: "info.circle")
                            .font(.system(size: 26))
                            .foregroundColor(.white)
                    }
                    .padding(.top, 55)
                    .padding(.trailing, 26)
                }

                Text("Admin Profile")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.top, 60)
            }
            .frame(height: 100)
            .ignoresSafeArea(edges: .top)

            // --- ICON ---
            ZStack {
                Circle()
                    .stroke(Color.black, lineWidth: 2)
                    .frame(width: 140, height: 140)

                Image(systemName: "person.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80, height: 80)
                    .foregroundColor(Color(red: 0/255, green: 128/255, blue: 128/255))
            }
            .padding(.top, -20)

            // --- EMAIL FIELD ---
            TextField("E-Mail", text: $myemail)
                .padding()
                .foregroundColor(.black)
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.black))
                .padding(.horizontal, 25)

            // --- PASSWORD FIELDS ---
            VStack(alignment: .leading, spacing: 6) {
                SecureField("Change Password", text: $newPassword)
                    .padding()
                    .foregroundColor(.black)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .focused($focusedField, equals: .newPassword)
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.black))

                Text("Password must be at least 8 characters, include 1 number and 1 special character")
                    .font(.system(size: 14))
                    .foregroundColor(.black)
            }
            .padding(.horizontal, 25)

            SecureField("Re-Enter Password", text: $reEnterPassword)
                .padding()
                .foregroundColor(.black)
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
                .focused($focusedField, equals: .reEnterPassword)
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.black))
                .padding(.horizontal, 25)

            // --- SAVE BUTTON ---
            Button(action: { updatePassword() }) {
                Text("Save Changes")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(red: 0/255, green: 137/255, blue: 133/255))
                    .cornerRadius(30)
            }
            .padding(.horizontal, 60)

            // --- LOGOUT BUTTON ---
            Button(action: { goToLogin = true }) {
                Text("Logout")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(red: 0/255, green: 137/255, blue: 133/255))
                    .cornerRadius(30)
            }
            .padding(.horizontal, 60)

            Spacer()
        }

        // --- ALERT ---
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Password Update"),
                message: Text(alertMessage),
                dismissButton: .default(Text("OK")) {
                    if alertMessage.contains("success") {
                        goToLogin = true
                    }
                }
            )
        }

        // --- NAV DESTINATIONS ---
        .navigationDestination(isPresented: $goToLogin) { LoginView() }
        .navigationDestination(isPresented: $goToAboutUs) { AboutUs() }
        .navigationDestination(isPresented: $gotoadmindash) { AdminDashboard() }        // 🚫 Hide System Back Button — show only custom one
        .navigationBarBackButtonHidden(true)
    }

    // MARK: - UPDATE PASSWORD
    func updatePassword() {
        focusedField = nil // Dismiss keyboard
        
        guard !newPassword.isEmpty, !reEnterPassword.isEmpty else {
            alertMessage = "Please enter both password fields"
            showAlert = true
            return
        }
        
        guard newPassword == reEnterPassword else {
            alertMessage = "Passwords do not match"
            showAlert = true
            return
        }
        
        let passwordPattern = "^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,}$"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passwordPattern)
        if !passwordTest.evaluate(with: newPassword) {
            alertMessage = "Password must be at least 8 characters, include 1 number and 1 special character"
            showAlert = true
            return
        }

        let parameters: [String: Any] = [
            "email": myemail,
            "password": newPassword
        ]
        
        NetworkManager.shared.postRequest(endpoint: "updateAdminProfile.php", parameters: parameters, responseType: UpdateProfileResponse.self) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    alertMessage = response.message
                    showAlert = true
                case .failure(let error):
                    alertMessage = "Error: \(error.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }
}

struct UpdateProfileResponse: Codable {
    let success: Bool
    let message: String
}

#Preview {
    NavigationStack {
        AdminProfile()
    }
}
