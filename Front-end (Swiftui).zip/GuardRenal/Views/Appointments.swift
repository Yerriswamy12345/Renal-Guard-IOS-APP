import SwiftUI

struct Appointments: View {
    // ✅ Navigation states
    @State private var goToDoctorDashboard = false
    @State private var goToAddSchedule = false
    @State private var goToViewAppointments = false

    var body: some View {
        NavigationStack {
            ZStack {
                // ✅ Background
                Color(red: 250/255, green: 240/255, blue: 246/255)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 40) {
                    
                    // ✅ Custom Top Bar
                    ZStack(alignment: .center) {
                        Color(red: 0/255, green: 128/255, blue: 128/255)
                        
                        HStack {
                            // 🔙 Back Button → Doctor Dashboard
                            Button(action: { goToDoctorDashboard = true }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "chevron.left")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)
                                    
                                    Text("Back")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundColor(.white)
                                        .padding(.top, 40)
                                }
                            }
                            .padding(.leading, 16)
                            
                            Spacer()
                        }
                        
                        // 🩺 Title
                        Text("Appointments")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.top, 40)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 100)
                    .ignoresSafeArea(edges: .top)
                    .padding(.top, -20)
                    
                    // ✅ Schedule Appointment Button
                    Button(action: {
                        goToAddSchedule = true  // 🔹 Trigger navigation
                    }) {
                        HStack(spacing: 15) {
                            Image(systemName: "plus")
                                .font(.system(size: 35, weight: .bold))
                                .foregroundColor(Color(red: 0/255, green: 128/255, blue: 128/255))
                            
                            Text("Schedule an Appointment")
                                .font(.system(size: 22, weight: .semibold))
                                .foregroundColor(.black)
                            
                            Spacer()
                        }
                        .padding(.horizontal, 20)
                        .frame(height: 80)
                        .frame(maxWidth: .infinity)
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.black, lineWidth: 1.2)
                        )
                        .padding(.horizontal, 25)
                    }
                    
                    // ✅ View Appointments Button
                    Button(action: {
                        goToViewAppointments = true  // 👈 Trigger navigation
                    }) {
                        HStack(spacing: 15) {
                            Image(systemName: "list.bullet.rectangle.portrait")
                                .font(.system(size: 35, weight: .bold))
                                .foregroundColor(Color(red: 0/255, green: 128/255, blue: 128/255))
                            
                            Text("View Appointments")
                                .font(.system(size: 22, weight: .semibold))
                                .foregroundColor(.black)
                            
                            Spacer()
                        }
                        .padding(.horizontal, 20)
                        .frame(height: 80)
                        .frame(maxWidth: .infinity)
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.black, lineWidth: 1.2)
                        )
                        .padding(.horizontal, 25)
                    }
                    
                    Spacer()
                }
            }
            // ✅ Hide default navigation bar
            .navigationBarBackButtonHidden(true)
            .navigationBarHidden(true)
            
            // ✅ Navigation Destinations
            .navigationDestination(isPresented: $goToAddSchedule) {
                AddSchedule()  // Navigates to AddSchedule screen
                    .navigationBarBackButtonHidden(true)
            }
            
            .navigationDestination(isPresented: $goToViewAppointments) {
                ViewAppointments()
                    .navigationBarBackButtonHidden(true)
            }
            
            .navigationDestination(isPresented: $goToDoctorDashboard) {
                DoctorDashboard()
                    .navigationBarBackButtonHidden(true)
            }
        }
    }
}

#Preview {
    Appointments()
}
