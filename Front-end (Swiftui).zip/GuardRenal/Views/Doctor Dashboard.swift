import SwiftUI

struct DoctorDashboard: View {

    // MARK: - States
    @State private var searchText = ""
    @State private var selectedTab = 0

    // Navigation Triggers
    @State private var goToAboutDieting = false
    @State private var goToProfile = false
    @State private var goToAppointments = false
    @State private var goToAddPatient = false
    @State private var goToPatientData = false

    // Patient Data
    @State private var patients: [DoctorPatientModel] = []
    @State private var selectedPatient: DoctorPatientModel? = nil

    // Delete
    @State private var showDeleteAlert = false
    @State private var showResultAlert = false
    @State private var alertMessage = ""
    @State private var patientToDelete: String? = nil

    // Logged-in Doctor
    @AppStorage("user_id") var doctorUserId: Int = 0
    @AppStorage("email") var doctorEmail: String = ""

    // MARK: - Fetch Patients
    func fetchPatients() {
        let parameters = ["doctor_email": doctorEmail]

        NetworkManager.shared.postRequest(
            endpoint: "get_patients.php",
            parameters: parameters,
            responseType: DoctorPatientResponse.self
        ) { result in
            DispatchQueue.main.async {
                if case .success(let response) = result, response.success {
                    self.patients = response.patients
                }
            }
        }
    }

    // MARK: - Delete Patient
    func deletePatientFromServer(patientID: String) {
        let parameters = ["patient_id": patientID]

        NetworkManager.shared.postRequest(
            endpoint: "delete.php",
            parameters: parameters,
            responseType: DeleteResponse.self
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    alertMessage = response.message
                    if response.success {
                        patients.removeAll { $0.patientNo == patientID }
                    }
                case .failure(let error):
                    alertMessage = error.localizedDescription
                }
                showResultAlert = true
            }
        }
    }

    // MARK: - Filter
    var filteredPatients: [DoctorPatientModel] {
        let key = searchText.lowercased()
        return key.isEmpty ? patients : patients.filter {
            $0.displayName.lowercased().contains(key) ||
            $0.displayPatientNo.lowercased().contains(key)
        }
    }

    // MARK: - BODY
    var body: some View {
            VStack(spacing: 0) {
                topBar
                searchBar
                patientList
                bottomBar
            }
            .background(Color.white)
            .onAppear { fetchPatients() }

            // MARK: - Navigation
            .navigationDestination(isPresented: $goToAddPatient) {
                AddPatient()
                    .navigationBarBackButtonHidden(true)
            }

            .navigationDestination(isPresented: $goToProfile) {
                ProfileView()
                    .navigationBarBackButtonHidden(true)
            }

            .navigationDestination(isPresented: $goToAppointments) {
                Appointments()
                    .navigationBarBackButtonHidden(true)
            }

            .navigationDestination(isPresented: $goToAboutDieting) {
                AboutDieting()
                    .navigationBarBackButtonHidden(true)
            }

            .navigationDestination(isPresented: $goToPatientData) {
                if let patient = selectedPatient {
                    PatientData(patient: patient)
                        .navigationBarBackButtonHidden(true)
                }
            }
        .navigationBarBackButtonHidden(true) // ✅ removes top chevron
        .alert("Delete Patient?", isPresented: $showDeleteAlert) {
            Button("Cancel", role: .cancel) {}
            Button("Delete", role: .destructive) {
                if let id = patientToDelete {
                    deletePatientFromServer(patientID: id)
                }
            }
        }
        .alert("Status", isPresented: $showResultAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(alertMessage)
        }
    }

    // MARK: - TOP BAR
    private var topBar: some View {
        ZStack {
            Color(red: 0/255, green: 128/255, blue: 128/255)

            HStack {
                Button {
                    goToAppointments = true
                } label: {
                    Image(systemName: "calendar")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                }
                .padding(.leading, 20)
                .padding(.top, 40)

                Spacer()

                Button {
                    goToAboutDieting = true
                } label: {
                    Image(systemName: "info.circle")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                }
                .padding(.trailing, 20)
                .padding(.top, 40)
            }

            Text("Doctor Dashboard")
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(.white)
                .padding(.top, 40)
        }
        .frame(height: 100)
        .ignoresSafeArea(edges: .top)
    }

    // MARK: - SEARCH BAR
    private var searchBar: some View {
        HStack {
            Image(systemName: "magnifyingglass")
            TextField("Search with Patient No or Name", text: $searchText)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(radius: 2)
        .padding(.horizontal, 20)
        .padding(.top, -30)
    }

    // MARK: - PATIENT LIST
    private var patientList: some View {
        ScrollView {
            VStack(spacing: 15) {
                ForEach(filteredPatients) { patient in
                    patientCard(patient)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 70)
        }
    }

    private func patientCard(_ patient: DoctorPatientModel) -> some View {
        VStack(spacing: 10) {

            HStack {
                Image("Image 3")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .clipShape(Circle())

                VStack(alignment: .leading) {
                    Text("Name: \(patient.displayName)").bold()
                    Text("Age: \(patient.displayAge)")
                    Text("Gender: \(patient.displayGender)")
                    Text("Email: \(patient.displayEmail)")
                        .font(.system(size: 13))
                }

                Spacer()
                Text(patient.displayPatientNo).bold()
            }

            HStack {
                Button("Delete") {
                    patientToDelete = patient.patientNo
                    showDeleteAlert = true
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)

                Spacer()

                Button("View") {
                    selectedPatient = patient
                    goToPatientData = true
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 3)
    }

    // MARK: - BOTTOM BAR
    private var bottomBar: some View {
        HStack {
            Spacer()
            navItem(icon: "house.fill", title: "Home") {}
            Spacer()
            navItem(icon: "plus.circle.fill", title: "Add") {
                goToAddPatient = true
            }
            Spacer()
            navItem(icon: "person.fill", title: "Profile") {
                goToProfile = true
            }
            Spacer()
        }
        .frame(height: 70)
        .background(Color.white)
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(Color.black)
        )
        .padding(.horizontal)
    }

    private func navItem(icon: String, title: String, action: @escaping () -> Void) -> some View {
        VStack {
            Image(systemName: icon).font(.system(size: 28))
            Text(title)
        }
        .onTapGesture { action() }
    }
}

#Preview {
    DoctorDashboard()
}
