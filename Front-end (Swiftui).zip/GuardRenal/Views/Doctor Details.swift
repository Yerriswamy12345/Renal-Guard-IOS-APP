import SwiftUI

// MARK: - API Response Models
struct AssignedDoctorResponse: Codable {
    let success: Bool
    let message: String?
    let doctor: Doctor?
}

// MARK: - ViewModel
class DoctorDetailsViewModel: ObservableObject {
    @Published var doctor: Doctor?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func fetchAssignedDoctor(patientEmail: String) {
        guard !patientEmail.isEmpty else {
            self.errorMessage = "Patient email not found"
            return
        }
        
        // Ensure we are on main thread for UI updates
        DispatchQueue.main.async {
            self.isLoading = true
            self.errorMessage = nil
        }
        
        let parameters = ["email": patientEmail]
        
        // Use getRequest if your NetworkManager supports query params for GET, 
        // OR use postRequest if the PHP expects POST/Body.
        // The PHP code checks $_GET['email'] ?? $_POST['email'] ?? input stream
        // So we can use POST for safety with JSON body.
        
        NetworkManager.shared.postRequest(
            endpoint: "getAssignedDoctor.php",
            parameters: parameters,
            responseType: AssignedDoctorResponse.self
        ) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let response):
                    if response.success {
                        self?.doctor = response.doctor
                    } else {
                        self?.errorMessage = response.message ?? "No doctor assigned"
                    }
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
}

// MARK: - View
struct DoctorDetails: View {
    @StateObject private var viewModel = DoctorDetailsViewModel()
    
    // User Session
    @AppStorage("email") private var patientEmail: String = ""
    @Environment(\.dismiss) private var dismiss
    
    // Optional doctor passed from Admin Dashboard
    var passedDoctor: Doctor?
    
    init(doctor: Doctor? = nil) {
        self.passedDoctor = doctor
    }
    
    // Computed property to determine which doctor to show
    var displayDoctor: Doctor? {
        return passedDoctor ?? viewModel.doctor
    }
    
    var body: some View {
        ZStack {
            // Background
            Color(red: 250/255, green: 240/255, blue: 246/255)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                
                // MARK: - TOP BAR
                ZStack {
                    Color(red: 0/255, green: 128/255, blue: 128/255)
                    
                    HStack {
                        // Custom Back Button

                        
                        Button(action: {
                            dismiss()
                        }) {
                             Image(systemName: "chevron.left")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundColor(.white)
                            Text("Back")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.white)
                                .padding(.top, 0)
                        }
                        .padding(.leading, 16)
                        .padding(.top, 40)
                        
                        Spacer()
                    }
                    
                    // Title
                    Text("Doctor Details")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 40)
                }
                .frame(height: 100)
                .ignoresSafeArea(edges: .top)
                
                // MARK: - CONTENT
                // If we have a passed doctor, we don't show loading/error from viewModel (unless we want to support verification?)
                // If passedDoctor is nil, we rely on viewModel state.
                
                if passedDoctor == nil && viewModel.isLoading {
                    Spacer()
                    ProgressView("Loading assigned doctor...")
                        .progressViewStyle(CircularProgressViewStyle(tint: Color(red: 0/255, green: 128/255, blue: 128/255)))
                        .scaleEffect(1.5)
                    Spacer()
                } else if passedDoctor == nil, let error = viewModel.errorMessage {
                    Spacer()
                    VStack(spacing: 15) {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.system(size: 50))
                            .foregroundColor(.orange)
                        Text(error)
                            .font(.headline)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        Button("Retry") {
                            viewModel.fetchAssignedDoctor(patientEmail: patientEmail)
                        }
                        .foregroundColor(Color(red: 0/255, green: 128/255, blue: 128/255))
                    }
                    Spacer()
                } else if let doctor = displayDoctor {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 15) {
                            
                            // Doctor Card
                            HStack(alignment: .center, spacing: 15) {
                                Image(systemName: "person.circle.fill") // Placeholder
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 70, height: 70)
                                    .foregroundColor(.gray)
                                    .clipShape(Circle())
                                
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(doctor.name)
                                        .font(.system(size: 22, weight: .bold))
                                    
                                    if !doctor.doctor_id.isEmpty {
                                        Text("ID: \(doctor.doctor_id)")
                                            .font(.system(size: 18))
                                            .foregroundColor(.secondary)
                                    }
                                }
                                Spacer()
                            }
                            .padding(15)
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                            
                            // About Section
                            VStack(alignment: .leading, spacing: 15) {
                                Text("About The Doctor")
                                    .font(.system(size: 20, weight: .bold))
                                
                                VStack(alignment: .leading, spacing: 12) {
                                    InfoRow(icon: "envelope.fill", title: "Email", value: doctor.email)
                                    InfoRow(icon: "phone.fill", title: "Phone", value: doctor.phone)
                                    InfoRow(icon: "stethoscope", title: "Specialization", value: doctor.specialization)
                                    InfoRow(icon: "graduationcap.fill", title: "Education", value: doctor.education)
                                    InfoRow(icon: "mappin.and.ellipse", title: "Location", value: doctor.location)
                                }
                                .padding(15)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(
                                    RoundedRectangle(cornerRadius: 15)
                                        .stroke(Color.black, lineWidth: 1)
                                )
                            }
                        }
                        .padding(20)
                    }
                } else {
                    Spacer()
                    Text("No Doctor Found")
                        .font(.title3)
                        .foregroundColor(.gray)
                        .padding()
                    Spacer()
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .onAppear {
            // Only fetch if no doctor was passed AND we haven't loaded one yet
            if passedDoctor == nil {
                viewModel.fetchAssignedDoctor(patientEmail: patientEmail)
            }
        }
    }
}

// Helper View for info rows
struct InfoRow: View {
    let icon: String
    let title: String
    let value: String?
    
    var body: some View {
        HStack(alignment: .top) {
            Image(systemName: icon)
                .foregroundColor(Color(red: 0/255, green: 128/255, blue: 128/255))
                .frame(width: 24)
            
            VStack(alignment: .leading) {
                Text(title)
                    .font(.caption)
                    .foregroundColor(.secondary)
                Text(value ?? "Not specified")
                    .font(.body)
            }
        }
    }
}

struct DoctorDetails_Previews: PreviewProvider {
    static var previews: some View {
        DoctorDetails()
    }
}
