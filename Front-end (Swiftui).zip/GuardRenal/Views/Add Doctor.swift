import SwiftUI

struct AddDoctor: View {

    // MARK: - Navigation
    @State private var goToDashboard = false

    // ✅ Logged-in Admin ID
    @AppStorage("user_id") var adminUserId: Int = 1

    // MARK: - Form Fields
    @State private var name = "test2"
    @State private var password = "test@123"
    @State private var email = "test2@gmail.com"
    @State private var mobile = "1234567890"
    @State private var specialization = "cardiologist"
    @State private var education = "mbbs"
    @State private var location = "chennai"

    // MARK: - Alert
    @State private var showAlert = false
    @State private var alertMessage = ""

    @FocusState private var focusedField: Field?
    
    enum Field {
        case name, password, email, mobile, specialization, education, location
    }

    var body: some View {
        ZStack {

            Color(red: 250/255, green: 240/255, blue: 246/255)
                .ignoresSafeArea()

            VStack(spacing: 0) {

                // MARK: - TOP BAR
                ZStack {
                    Color(red: 0/255, green: 128/255, blue: 128/255)

                    HStack {
                        Button {
                            goToDashboard = true
                        } label: {
                            HStack {
                                Image(systemName: "chevron.left")
                                Text("Back")
                            }
                            .foregroundColor(.white)
                            .padding(.top, 40)
                        }
                        .padding(.leading, 16)

                        Spacer()
                    }

                    Text("Add Doctor")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 40)
                }
                .frame(height: 100)
                .ignoresSafeArea(edges: .top)

                // MARK: - FORM
                VStack(alignment: .leading, spacing: 15) {

                    Text("Doctor Details")
                        .font(.system(size: 20, weight: .bold))

                    Group {
                        TextField("Name", text: $name)
                            .focused($focusedField, equals: .name)
                        Divider()

                        SecureField("Password", text: $password)
                            .focused($focusedField, equals: .password)
                        Divider()

                        TextField("Email", text: $email)
                            .focused($focusedField, equals: .email)
                        Divider()

                        TextField("Mobile Number", text: $mobile)
                            .focused($focusedField, equals: .mobile)
                        Divider()

                        TextField("Specialization", text: $specialization)
                            .focused($focusedField, equals: .specialization)
                        Divider()

                        TextField("Education", text: $education)
                            .focused($focusedField, equals: .education)
                        Divider()

                        TextField("Location", text: $location)
                            .focused($focusedField, equals: .location)
                        Divider()
                    }
                    .font(.system(size: 18))
                    .textInputAutocapitalization(.never)

                    // MARK: - SAVE BUTTON
                    HStack {
                        Spacer()
                        Button {
                            saveDoctor()
                        } label: {
                            Text("Save")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.black)
                                .frame(width: 120, height: 44)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(
                                            Color(red: 0/255, green: 128/255, blue: 128/255),
                                            lineWidth: 2
                                        )
                                )
                        }
                        Spacer()
                    }
                    .padding(.top, 20)
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.black, lineWidth: 1)
                )
                .padding(.horizontal, 16)
                .padding(.top, -15)

                Spacer()

                // MARK: - BACK TO HOME BUTTON
                Button {
                    goToDashboard = true
                } label: {
                    Text("Back to Homepage")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                        .cornerRadius(25)
                        .padding(.horizontal, 20)
                }
                .padding(.bottom, 10)
            }
        }
        // MARK: - ALERT
        .alert(alertMessage, isPresented: $showAlert) {
            Button("OK") {
                if alertMessage == "Doctor added successfully" {
                    goToDashboard = true
                }
            }
        }

        // MARK: - NAVIGATION
        .navigationDestination(isPresented: $goToDashboard) {
            AdminDashboard()
        }

        .navigationBarBackButtonHidden(true)
    }

    // MARK: - API CALL
    func saveDoctor() {
        focusedField = nil // Dismiss keyboard
        
        guard !name.isEmpty, !email.isEmpty, !mobile.isEmpty, !password.isEmpty else {
            alertMessage = "Please fill in all required fields"
            showAlert = true
            return
        }

        let parameters: [String: Any] = [
            "name": name,
            "email": email,
            "phone": mobile,
            "password": password,
            "specialization": specialization,
            "education": education,
            "location": location
        ]
        
        NetworkManager.shared.postRequest(endpoint: "add_doctor.php", parameters: parameters, responseType: AddDoctorResponse.self) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    alertMessage = response.message
                    showAlert = true
                case .failure(let error):
                    alertMessage = "Error: \(error.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }
}

struct AddDoctorResponse: Codable {
    let success: Bool
    let message: String
}

#Preview {
    NavigationStack {
        AddDoctor()
    }
}
