import SwiftUI

// MARK: - API Models
struct DoctorProfileResponse: Codable {
    let success: Bool
    let message: String?
    let data: DoctorProfile?
}

struct DoctorProfile: Codable {
    let name: String
    let email: String
    let phone: String
    let specialization: String?
    let education: String?
    let location: String?
}

struct ProfileView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var name = ""
    @State private var mobile = ""
    @State private var email = ""
    @State private var specialization = ""
    @State private var education = ""
    @State private var location = ""

    @State private var changePassword = ""
    @State private var reEnterPassword = ""

    @State private var goToAboutUs = false
    @State private var goToLogin = false
    @AppStorage("email") var storedEmail: String = ""
    
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    @FocusState private var focusedField: Field?
    
    enum Field {
        case name, mobile, specialization, education, location, password, reEnterPassword
    }

    // MARK: - FETCH PROFILE
    func fetchDoctorProfile() {
        guard !storedEmail.isEmpty else { return }
        
        let parameters = ["email": storedEmail]
        NetworkManager.shared.postRequest(
            endpoint: "getDoctorProfile.php",
            parameters: parameters,
            responseType: DoctorProfileResponse.self
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.success, let profile = response.data {
                        self.name = profile.name
                        self.email = profile.email
                        self.mobile = profile.phone
                        self.specialization = profile.specialization ?? ""
                        self.education = profile.education ?? ""
                        self.location = profile.location ?? ""
                    }
                case .failure(let error):
                    print("Error fetching profile: \(error.localizedDescription)")
                }
            }
        }
    }

    // MARK: - BODY UI
    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()

            VStack(spacing: 0) {
                // --- TOP BAR ---
                ZStack {
                    Color(red: 0/255, green: 128/255, blue: 128/255)

                    HStack {
                        Button(action: { goToAboutUs = true }) {
                            Image(systemName: "info.circle")
                                .font(.system(size: 28))
                                .foregroundColor(.white)
                                .padding(.top, 40)
                        }
                        .padding(.leading, 16)

                        Spacer()

                        Text("Profile")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.top, 40)

                        Spacer()

                        Button(action: { goToLogin = true }) {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .font(.system(size: 22))
                                .foregroundColor(.white)
                                .padding(.top, 40)
                        }
                        .padding(.trailing, 16)
                    }
                }
                .frame(height: 100)
                .padding(.top, -65)

                // --- FORM CONTENT ---
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 15) {
                        VStack(spacing: 15) {
                            Image("Image 5")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)

                            Group {
                                profileField(title: "Name", text: $name)
                                    .focused($focusedField, equals: .name)

                                profileField(title: "Mobile Number", text: $mobile)
                                    .focused($focusedField, equals: .mobile)

                                profileField(title: "Specialization", text: $specialization)
                                    .focused($focusedField, equals: .specialization)

                                profileField(title: "Education", text: $education)
                                    .focused($focusedField, equals: .education)

                                profileField(title: "Location", text: $location)
                                    .focused($focusedField, equals: .location)

                                profileField(
                                    title: "Change Password",
                                    text: $changePassword,
                                    isSecure: true
                                )
                                .focused($focusedField, equals: .password)

                                Text("Password must be at least 8 characters, include 1 number & 1 special character")
                                    .font(.system(size: 13))

                                profileField(
                                    title: "Re-Enter Password",
                                    text: $reEnterPassword,
                                    isSecure: true
                                )
                                .focused($focusedField, equals: .reEnterPassword)
                            }
                            .padding(.horizontal, 10)
                        }
                        .padding()
                        .background(Color(red: 230/255, green: 242/255, blue: 242/255))
                        .cornerRadius(15)
                        .shadow(radius: 5)
                        .padding(.bottom, 90)
                    }
                }
            }
        }
        // ✅ SWIPE BACK (LEFT → RIGHT)
        .gesture(
            DragGesture()
                .onEnded { value in
                    if value.translation.width > 100 {
                        dismiss()
                    }
                }
        )

        // MARK: - FIXED BOTTOM BUTTON
        .overlay(alignment: .bottom) {
            Button(action: {
                updateDoctorPassword()
            }) {
                Text("Save & Exit")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                    .cornerRadius(10)
                    .padding(.horizontal, 60)
            }
            .padding(.bottom, 15)
            .ignoresSafeArea(.keyboard)
        }

        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Password Update"),
                message: Text(alertMessage),
                dismissButton: .default(Text("OK")) {
                    if alertMessage.contains("success") {
                        goToLogin = true
                    }
                }
            )
        }

        .onAppear { fetchDoctorProfile() }

        .navigationDestination(isPresented: $goToAboutUs) { AboutUs() }
        .navigationDestination(isPresented: $goToLogin) { LoginView() }
    }

    // MARK: - REUSABLE FIELD UI
    func profileField(title: String, text: Binding<String>, isSecure: Bool = false) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(size: 16))

            Group {
                if isSecure {
                    SecureField(title, text: text)
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)
                } else {
                    TextField(title, text: text)
                }
            }
            .padding(10)
            .background(Color.white)
            .cornerRadius(6)
            .overlay(
                RoundedRectangle(cornerRadius: 6)
                    .stroke(Color.gray.opacity(0.6))
            )
        }
    }

    // MARK: - UPDATE PROFILE
    func updateDoctorPassword() {
        focusedField = nil
        
        if !changePassword.isEmpty {
            if changePassword != reEnterPassword {
                alertMessage = "Passwords do not match"
                showAlert = true
                return
            }
            
            let passwordPattern = "^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,}$"
            let passwordTest = NSPredicate(format: "SELF MATCHES %@", passwordPattern)
            if !passwordTest.evaluate(with: changePassword) {
                alertMessage = "Password must be at least 8 characters, include 1 number & 1 special character"
                showAlert = true
                return
            }
        }

        var parameters: [String: Any] = [
            "email": storedEmail,
            "name": name,
            "phone": mobile,
            "specialization": specialization,
            "education": education,
            "location": location
        ]
        
        if !changePassword.isEmpty {
            parameters["password"] = changePassword
        }
        
        NetworkManager.shared.postRequest(
            endpoint: "updateDoctorProfile.php",
            parameters: parameters,
            responseType: DoctorUpdateResponse.self
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    alertMessage = response.message
                    showAlert = true
                case .failure(let error):
                    alertMessage = "Error: \(error.localizedDescription)"
                    showAlert = true
                }
            }
        }
    }
}

struct DoctorUpdateResponse: Codable {
    let success: Bool
    let message: String
}

#Preview {
    ProfileView()
}
