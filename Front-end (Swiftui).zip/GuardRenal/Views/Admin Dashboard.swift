import SwiftUI

// MARK: - Models
struct DoctorListResponse: Codable {
    let success: Bool // Changed from status to success (bool)
    let doctors: [Doctor]
}



struct Doctor: Codable, Identifiable {
    var id: String { doctor_id }
    
    let doctor_id: String
    let name: String
    let email: String
    let phone: String
    let specialization: String?
    let education: String?
    let location: String?
    
    // We already use coding keys implicitly, but if JSON is "user_id" wait...
    // get_doctors.php returns: doctor_id, name, email ...
    // So "user_id" in struct was WRONG if it expected "user_id" from JSON.
    // I changed it to doctor_id which is correct for JSON.
}

// MARK: - Admin Dashboard
struct AdminDashboard: View {
    
    @AppStorage("user_id") var adminUserId: Int = 0
    
    @State private var searchText = ""
    @State private var showConfirmation = false
    @State private var doctors: [Doctor] = []
    @State private var isLoading = false
    @State private var selectedDoctorId: String = ""
    @State private var selectedDoctor: Doctor? = nil
    @State private var showSuccess = false

    // Navigation
    @State private var goToAddDoctor = false
    @State private var goToAdminProfile = false
    @State private var goToDoctorDetails = false

    // MARK: - FILTER
    var filteredDoctors: [Doctor] {
        if searchText.isEmpty { return doctors }
        return doctors.filter { doctor in
            doctor.name.lowercased().contains(searchText.lowercased()) ||
            doctor.doctor_id.lowercased().contains(searchText.lowercased())
        }
    }
    
    // MARK: - FETCH ALL DOCTORS
    func fetchDoctors() {
        isLoading = true
        print("🔍 Fetching all doctors (Network)...")
        
        NetworkManager.shared.getRequest(endpoint: "get_doctors.php", responseType: DoctorListResponse.self) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let response):
                    // get_doctors.php returns {"success": true, "doctors": [...] }
                    // DoctorListResponse matches this structure?
                    // struct DoctorListResponse: Codable { let status: String; let count: Int; let doctors: [Doctor] } (from line 4)
                    // PHP returns "success" (bool), "doctors" (array).
                    // Mismatch: PHP uses "success", struct uses "status".
                    // I need to update DoctorListResponse struct too.
                    self.doctors = response.doctors
                    
                case .failure(let error):
                    print("Error fetching doctors: \(error)")
                }
            }
        }
    }
    
    // MARK: - DELETE DOCTOR
    func deleteDoctor(doctorId: String) {
        let parameters = ["doctor_id": doctorId]
        NetworkManager.shared.postRequest(endpoint: "delete_doctor.php", parameters: parameters, responseType: DeleteResponse.self) { result in
            DispatchQueue.main.async {
               showConfirmation = false
               switch result {
               case .success(let response):
                   if response.success {
                       withAnimation { showSuccess = true }
                       DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                           withAnimation { showSuccess = false }
                       }
                       fetchDoctors()
                   } else {
                       print("Delete failed: \(response.message)")
                   }
               case .failure(let error):
                   print("Error deleting: \(error)")
               }
            }
        }
    }
    
    // MARK: - BODY
    var body: some View {
        ZStack {
            
            Color(red: 250/255, green: 240/255, blue: 246/255)
                .ignoresSafeArea()
            
            VStack(spacing: 5) {
                
                // HEADER
                ZStack {
                    Color(red: 0/255, green: 128/255, blue: 128/255)
                    Text("Admin Dashboard")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.top, 40)
                }
                .frame(height: 100)
                .ignoresSafeArea()
                
                // SEARCH FIELD
                HStack {
                    Image(systemName: "magnifyingglass")
                    TextField("Search by name or ID", text: $searchText)
                }
                .padding(14)
                .background(Color.white)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black, lineWidth: 2)
                )
                .padding(.horizontal, 14)
                .padding(.top, -20)
                
                // DOCTOR LIST
                ScrollView {
                    if isLoading {
                        ProgressView("Loading doctors…")
                            .padding()
                    } else if filteredDoctors.isEmpty {
                        Text("No doctors found")
                            .foregroundColor(.gray)
                            .padding()
                    } else {
                        ForEach(filteredDoctors) { doctor in
                            VStack {
                                HStack(alignment: .top, spacing: 12) {
                                    Image("Image 5")
                                        .resizable()
                                        .frame(width: 60, height: 60)
                                        .clipShape(Circle())
                                        .padding(.leading, 12)
                                    
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text("Name: \(doctor.name)")
                                            .font(.system(size: 18, weight: .bold))
                                        Text("Email: \(doctor.email)")
                                        Text("Specialization: \(doctor.specialization ?? "Not provided")")
                                    }
                                    
                                    Spacer()
                                    
                                    Text("ID: \(doctor.doctor_id)")
                                        .font(.system(size: 18, weight: .semibold))
                                        .padding(.trailing, 10)
                                }
                                .padding(.top, 12)
                                
                                HStack(spacing: 20) {
                                    Button("Delete") {
                                        selectedDoctorId = doctor.doctor_id
                                        showConfirmation = true
                                    }
                                    .padding(.horizontal, 30)
                                    .padding(.vertical, 12)
                                    .background(Color.red)
                                    .foregroundColor(.white)
                                    .cornerRadius(25)
                                    
                                    Spacer()
                                    
                                    Button("View") {
                                        selectedDoctor = doctor
                                        goToDoctorDetails = true
                                    }
                                    .padding(.horizontal, 30)
                                    .padding(.vertical, 12)
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(25)
                                }
                                .padding(.bottom, 16)
                            }
                            .background(
                                RoundedRectangle(cornerRadius: 18)
                                    .fill(Color.white)
                                    .shadow(radius: 5)
                            )
                            .padding(.horizontal, 14)
                            .padding(.top, 8)
                        }
                    }
                }
                .onAppear { fetchDoctors() }
                
                // MARK: - BOTTOM BAR
                bottomBar
            }
            
            // CONFIRMATION POPUP
            if showConfirmation {
                Color.black.opacity(0.4).ignoresSafeArea()
                
                VStack(spacing: 15) {
                    Text("Are You Sure?")
                        .font(.title3.bold())
                    
                    Text("Deleting this doctor will remove their account permanently.")
                        .multilineTextAlignment(.center)
                    
                    HStack(spacing: 30) {
                        Button("Yes") { deleteDoctor(doctorId: selectedDoctorId) }
                            .frame(width: 80, height: 40)
                            .background(Color.red)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                        
                        Button("No") { showConfirmation = false }
                            .frame(width: 80, height: 40)
                            .background(Color.gray.opacity(0.3))
                            .cornerRadius(10)
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(12)
            }
            
            // SUCCESS MESSAGE
            if showSuccess {
                Text("Doctor Deleted Successfully")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(10)
                    .transition(.opacity)
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .navigationDestination(isPresented: $goToAddDoctor) { AddDoctor() }
        .navigationDestination(isPresented: $goToAdminProfile) { AdminProfile() }
        .navigationDestination(isPresented: $goToDoctorDetails) {
            DoctorDetails(doctor: selectedDoctor)
        }
    }
    
    // MARK: - BOTTOM BAR (icons only)
    private var bottomBar: some View {
        GeometryReader { geometry in
            HStack {
                Spacer()
                
                navItem(icon: "house.fill") {
                    // Home (stay in same screen)
                }
                
                Spacer()
                
                navItem(icon: "plus.circle.fill") {
                    goToAddDoctor = true
                }
                
                Spacer()
                
                navItem(icon: "person.fill") {
                    goToAdminProfile = true
                }
                
                Spacer()
            }
            .frame(width: min(geometry.size.width - 40, 600))
            .padding(.vertical, 8)
            .background(Color.white)
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.black, lineWidth: 1))
            .frame(maxWidth: .infinity)
        }
        .frame(height: 70)
    }
    
    private func navItem(icon: String, action: @escaping () -> Void) -> some View {
        Image(systemName: icon)
            .font(.system(size: 30))
            .onTapGesture { action() }
    }
}

// MARK: - PREVIEW
struct AdminDashboard_Previews: PreviewProvider {
    static var previews: some View {
        AdminDashboard()
    }
}
