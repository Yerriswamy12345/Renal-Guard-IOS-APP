import SwiftUI

struct RiskScore: View {

    // MARK: - Received From Assessment
    var patientScore: Int
    let patientId: String
    let patientEmail: String
    var totalScore: Int { 25 }

    // MARK: - Navigation
    @State private var goToAssessment = false
    @State private var goToDashboard = false

    // MARK: - Scale Range
    private let minScore = 5.0
    private let maxScore = 25.0

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 250/255, green: 240/255, blue: 246/255)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 25) {

                    // TOP BAR
                    topBar

                    // SCORE BOXES
                    HStack(spacing: 40) {
                        scoreBox(title: "Patient Score", value: patientScore)
                        scoreBox(title: "Total Score", value: totalScore)
                    }
                    .padding(.top, -10)

                    // SCALE BAR
                    riskScale

                    // RECOMMENDATIONS
                    recommendationSection

                    Spacer()

                    // DONE BUTTON
                    Button(action: {
                        goToDashboard = true
                    }) {
                        Text("Done")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .font(.headline)
                            .foregroundColor(.white)
                            .background(Color(red: 0/255, green: 128/255, blue: 128/255))
                            .cornerRadius(30)
                            .padding(.horizontal, 50)
                    }
                    .padding(.bottom, 30)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(isPresented: $goToDashboard) {
                DoctorDashboard()
            }
            .navigationDestination(isPresented: $goToAssessment) {
                Assessment(patientId: patientId, patientEmail: patientEmail)
            }
        }
    }

    // MARK: - TOP BAR
    private var topBar: some View {
        ZStack {
            Color(red: 0/255, green: 128/255, blue: 128/255)

            HStack {
                Button { goToAssessment = true } label: {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .foregroundColor(.white)
                    .padding(.top, 40)
                }
                .padding(.leading, 16)

                Spacer()
            }

            Text("Risk Score")
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(.white)
                .padding(.top, 40)
        }
        .frame(height: 100)
        .ignoresSafeArea(edges: .top)
    }

    // MARK: - SCORE BOX
    private func scoreBox(title: String, value: Int) -> some View {
        VStack(spacing: 10) {
            Text("\(value)")
                .font(.largeTitle)
                .bold()
                .frame(width: 100, height: 60)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 1))

            Text(title)
                .font(.headline)
        }
    }

    // MARK: - SCALE BAR
    private var riskScale: some View {
        VStack(spacing: 15) {
            Text("Scale")
                .font(.headline)

            GeometryReader { geo in
                let width = geo.size.width
                let normalized = CGFloat((Double(patientScore) - minScore) / (maxScore - minScore))
                let arrowX = max(0, min(normalized * width, width))

                VStack(spacing: 6) {

                    // ARROW
                    Image(systemName: "triangle.fill")
                        .rotationEffect(.degrees(180))
                        .offset(x: arrowX - width/2)
                        .animation(.easeInOut(duration: 0.5), value: patientScore)

                    // COLOR BARS
                    HStack(spacing: 0) {
                        Rectangle().fill(Color.green).frame(width: width * 0.25)
                        Rectangle().fill(Color.yellow).frame(width: width * 0.35)
                        Rectangle().fill(Color.red).frame(width: width * 0.40)
                    }
                    .frame(height: 12)
                    .cornerRadius(6)

                    // LABELS
                    HStack {
                        Text("5")
                        Spacer()
                        Text("10")
                        Spacer()
                        Text("18")
                        Spacer()
                        Text("25")
                    }
                    .padding(.horizontal, 8)
                }
            }
            .frame(height: 60)
        }
        .padding(.horizontal, 30)
    }

    // MARK: - RECOMMENDATIONS
    private var recommendationSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            ForEach(recommendations(for: patientScore), id: \.self) { msg in
                Text("• \(msg)")
                    .font(.body)
            }
        }
        .padding(.horizontal)
    }

    private func recommendations(for score: Int) -> [String] {
        if score < 10 {
            return [
                "Ensure aseptic techniques are followed."
            ]
        } else if score < 18 {
            return [
                "Ensure aseptic techniques are followed.",
                "Encourage planning for AV fistula."
            ]
        } else {
            return [
                "Ensure aseptic techniques are followed.",
                "Encourage planning for AV fistula.",
                "High risk detected: Consider hospital admission and close monitoring."
            ]
        }
    }
}

#Preview {
    RiskScore(patientScore: 15, patientId: "PAT001", patientEmail: "test@gmail.com")
}
