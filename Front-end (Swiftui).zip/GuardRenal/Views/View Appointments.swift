import SwiftUI

struct ViewAppointments: View {

    @StateObject private var viewModel = ScheduleViewModel()
    @AppStorage("email") private var doctorEmail: String = ""

    // ✅ Navigation
    @State private var goToAppointments = false

    var body: some View {
        NavigationStack {
            ZStack {
                // ✅ Background
                Color(red: 250/255, green: 240/255, blue: 246/255)
                    .ignoresSafeArea()

                VStack(spacing: 0) {

                    // ✅ Top Bar
                    ZStack(alignment: .center) {
                        Color(red: 0/255, green: 128/255, blue: 128/255)

                        HStack {
                            // 🔙 Back → Appointments
                            Button(action: {
                                goToAppointments = true
                            }) {
                                HStack(spacing: 4) {
                                    Image(systemName: "chevron.left")
                                        .font(.system(size: 20, weight: .bold))
                                        .foregroundColor(.white)

                                    Text("Back")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundColor(.white)
                                }
                            }
                            .padding(.leading, 16)
                            .padding(.top, 40)

                            Spacer()
                        }

                        // 🏥 Title
                        Text("Renal Guard")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.top, 40)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 100)
                    .ignoresSafeArea(edges: .top)
                    .padding(.top, -20)

                    // ✅ Scrollable Content
                    ScrollView(showsIndicators: false) {
                        VStack(spacing: 16) {
                            if viewModel.isLoading {
                                ProgressView("Loading...")
                                    .padding(.top, 50)
                            } else if viewModel.doctorSchedules.isEmpty {
                                Text("No schedules found")
                                    .foregroundColor(.gray)
                                    .padding(.top, 50)
                            } else {
                                ForEach(viewModel.doctorSchedules) { schedule in
                                    scheduleCard(schedule)
                                }
                            }
                        }
                        .padding(.horizontal, 10)
                        .padding(.top, 10)
                        .padding(.bottom, 20)
                    }
                }
            }
            .onAppear {
                Task {
                    await viewModel.fetchDoctorSchedules(doctorEmail: doctorEmail)
                }
            }
            .toolbar(.hidden, for: .navigationBar)

            // ✅ Navigation Destination
            .navigationDestination(isPresented: $goToAppointments) {
                Appointments()
                    .navigationBarBackButtonHidden(true)
            }
        }
    }

    // MARK: - Schedule Card
    @ViewBuilder
    func scheduleCard(_ schedule: APISchedule) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Date: \(schedule.available_date)")
                .font(.system(size: 18, weight: .semibold))

            Text("Time: \(schedule.start_time) - \(schedule.end_time)")
                .font(.system(size: 16))

            Text("Remaining: \(schedule.remaining)")
                .font(.system(size: 16))

            Text("Status: \(schedule.status)")
                .font(.system(size: 16))

            if !schedule.patients.isEmpty {
                Text("Booked Patients:")
                    .font(.system(size: 16, weight: .semibold))
                    .padding(.top, 5)

                ForEach(schedule.patients) { patient in
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text(patient.patient_name)
                                .fontWeight(.medium)
                            Spacer()
                            Text(patient.slot_time)
                            Spacer()
                            Text(patient.status)
                                .foregroundColor(patient.status.lowercased() == "attended" ? .green : .red)
                        }
                        Text(patient.patient_phone)
                            .font(.system(size: 12))
                            .foregroundColor(.gray)
                    }
                    .padding(.vertical, 4)
                    Divider()
                }
            }
        }
        .foregroundColor(.black)
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .cornerRadius(10)
        .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
    }
}

// Schedule Model removed as we now use APISchedule from ViewModel

#Preview {
    ViewAppointments()
}
