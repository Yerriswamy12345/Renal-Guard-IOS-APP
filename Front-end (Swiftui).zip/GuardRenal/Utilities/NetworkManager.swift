import Foundation

class NetworkManager {
    static let shared = NetworkManager()
    
    // MARK: - Configuration
    // IMPORTANT: Change this URL to your local IP address if running on a real device, 
    // or keep localhost if using a simulator.
    // Example for real device: "http://192.168.1.5/renalguard"
    // IMPORTANT: Change this URL to your local IP address if running on a real device.
    // Example for real device: "http://192.168.1.5/renalguard"
    static let baseURL = "http://localhost/renalguard"
    
    private init() {}
    
    enum APIError: Int, Error, LocalizedError {
        case invalidURL
        case requestFailed
        case decodingFailed
        case serverError
        case badRequest
        
        var errorDescription: String? {
            switch self {
            case .invalidURL: return "Invalid URL"
            case .requestFailed: return "Request Failed (Check Connection/URL)"
            case .decodingFailed: return "Decoding Failed (Invalid JSON or 500/404 HTML)"
            case .serverError: return "Server Error (500)"
            case .badRequest: return "Bad Request (400)"
            }
        }
    }
    
    // MARK: - Post Request
    func postRequest<T: Codable>(endpoint: String, parameters: [String: Any], responseType: T.Type, completion: @escaping (Result<T, APIError>) -> Void) {
        let urlString = "\(NetworkManager.baseURL)/\(endpoint)"
        guard let url = URL(string: urlString) else {
            completion(.failure(.invalidURL))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
        } catch {
            completion(.failure(.requestFailed))
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Network request error for \(urlString): \(error.localizedDescription)")
                completion(.failure(.requestFailed))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                completion(.failure(.requestFailed))
                return
            }
            
            guard let data = data else {
                completion(.failure(.requestFailed))
                return
            }
            
            // Print Raw Response
            if let jsonString = String(data: data, encoding: .utf8) {
                print("Response from \(endpoint): \(jsonString)")
            }
            
            // Check Status Code
            guard (200...299).contains(httpResponse.statusCode) else {
                print("HTTP Error Status: \(httpResponse.statusCode)")
                if httpResponse.statusCode == 500 { completion(.failure(.serverError)); return }
                if httpResponse.statusCode == 400 { completion(.failure(.badRequest)); return }
                completion(.failure(.requestFailed))
                return
            }
            
            do {
                let decodedResponse = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decodedResponse))
            } catch {
                print("Decoding error: \(error)")
                completion(.failure(.decodingFailed))
            }
        }.resume()
    }
    
    // MARK: - Get Request
    func getRequest<T: Codable>(endpoint: String, responseType: T.Type, completion: @escaping (Result<T, APIError>) -> Void) {
        let urlString = "\(NetworkManager.baseURL)/\(endpoint)"
        guard let url = URL(string: urlString) else {
            completion(.failure(.invalidURL))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let _ = error {
                completion(.failure(.requestFailed))
                return
            }
            
            guard let data = data else {
                completion(.failure(.requestFailed))
                return
            }
            
            do {
                let decodedResponse = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decodedResponse))
            } catch {
                completion(.failure(.decodingFailed))
            }
        }.resume()
    }
}
